# Shipping checklist

What has to be true before a build goes out. Short enough to actually work
through, and every item is checkable rather than a matter of opinion.

The application source is SAIF AI's own and carries no copyleft obligation
(see `LICENSE_AUDIT.md` for the measurement). This checklist covers the two
things that do: the copyleft libraries SAIF AI **links**, and the accuracy of
the notices the app shows about itself.


## 1. Before the build

- [ ] `python3 tools/licence/provenance.py --upstream /tmp/upstream-antigem --write`
      reports **0** identical files and **0** modified files.
- [ ] `python3 tools/licence/add_saif_headers.py` reports **0** files waiting
      to be stamped and **0** violations.
- [ ] No source file still mentions a licence the app is not under.

Re-measure the first two whenever a large body of code enters the tree. The
point of checking them is that a regression shows up before release, not after.


## 2. Copyleft components: what each one requires

Both are **linked unmodified**, which is what keeps their obligations small.

### JLaTeXMath — GPL-2.0-or-later with Classpath Exception

Used, via `ru.noties:jlatexmath-android`, to render LaTeX in replies.

- [ ] The library's copyright notice and licence text ship inside the APK.
- [ ] They are named in `THIRD_PARTY_NOTICES.md` and in the in-app
      **Settings → Licences & open source** screen.

Nothing further is required. The Classpath Exception in its own licence text
says that linking it with independent modules - which SAIF AI is - does not
place the combined work under the GPL.

### sora-editor — LGPL-2.1

Used as the code editor. LGPL is the *lesser* licence: linking a closed
application against an LGPL library is permitted, provided the user can
replace the library.

- [ ] The library's copyright notice and licence text ship inside the APK.
- [ ] They are named in `THIRD_PARTY_NOTICES.md` and in the in-app licences
      screen.
- [ ] The library is used **unmodified**, straight from Maven Central - so
      rebuilding against a different version is possible. If it is ever
      modified, those modifications become LGPL and have to be published.

### glibc — LGPL-2.1 (with the runtime exception)

Shipped inside `app/src/main/assets/glibc-min-arm64.tar` for the Linux
workspace.

- [ ] Used unmodified, as distributed by its upstream.
- [ ] Named as a bundled asset in `THIRD_PARTY_NOTICES.md`.


## 3. The notices inside the app

`Settings → Licences & open source` is the screen a user actually reads. It is
the part most likely to drift out of step with reality, so:

- [ ] Every third-party component listed in `THIRD_PARTY_NOTICES.md` appears
      there.
- [ ] Nothing is listed that the build no longer contains. The automation
      module is gone, so it must not be named as a component.
- [ ] The SAIF AI copyright line is present and unambiguous.


## 4. The source link

`SAIF_SOURCE_URL` is baked into `BuildConfig` and shown on the licences
screen.

- [ ] Set it when publishing a build, so the source for that exact build is
      available alongside the APK.

This is no longer a GPL v3 section 13 requirement - that obligation ended with
the upstream code. It is kept because publishing the source of what you ship
is the right default, and because the licences screen already offers the link.


## 5. Record

- [ ] Note the build number, the commit, and the output of the two tools from
      step 1. If a question is ever asked about a specific build, the answer
      should be a file, not a memory.
