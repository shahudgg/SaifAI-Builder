# Licence audit

What SAIF AI ships, who owns it, and how that was established. Every number in
this file is produced by a tool in `tools/licence/` against a real checkout of
the project SAIF AI's code used to sit alongside - measured, not estimated.

Reproduce it with:

```bash
git clone --depth 1 https://github.com/Santoshkurmi/antigem.git /tmp/upstream-antigem
python3 tools/licence/provenance.py --upstream /tmp/upstream-antigem --write
python3 tools/licence/add_saif_headers.py          # reports what is and is not stamped
```


## 1. Where this started

The application began as SAIF AI's own interface, chat, agent and studio code
wrapped around a large body of code taken from **AntiGem** by Santosh Kurmi
(https://github.com/Santoshkurmi/antigem), which is published under the
**GNU General Public License v3.0**.

Measured at the time, that body was:

| | files | lines |
|---|---|---|
| Original SAIF AI code | 672 | ~96,000 |
| Identical to upstream | 241 | 55,219 |
| Modified from upstream (60-95%) | 86 | 54,928 |
| Heavily reworked (20-60%) | 16 | 3,164 |
| Effectively different (<20%) | 4 | 274 |

Roughly half the source in the tree was upstream code. Under GPL v3 that made
the combined application a derivative work, with the full set of obligations
that follow - publishing the complete corresponding source, and licensing the
whole thing under GPL v3.

Two ways out existed: obtain a different licence from the upstream author, or
replace the upstream code with SAIF AI's own. The first was not available. The
second is what was done.


## 2. What was done

The upstream code was removed and replaced with SAIF AI's own implementations,
written from the behaviour SAIF AI needed rather than from the upstream source.

| Removed | Lines | Replaced by |
|---|---|---|
| `app/src/main/java/com/example/gemini/**` | 96,440 / 204 files | `com.example.saifcore` - the workspace, Linux environment, local bridge, agent backend, browser and feed, written for SAIF AI |
| `app/src/main/java/com/termux/**` | 3,252 / 12 files | `com.example.terminal` - terminal providers and provisioning |
| `app/src/main/proto/**` | 10,189 | removed; the protocol is expressed in Kotlin data classes |
| `agy_ide_bridge/`, `proto_generator/` | ~17,000 | removed |
| `docs/`, `extensions/`, `extension_docs/`, `scripts/` | ~21,000 | removed |
| `assets/browser-runtime/**` | ~800 | removed |
| `app/src/test`, `app/src/androidTest` | — | removed, along with the Robolectric and Roborazzi dependencies |
| `automation/**` | 23,093 / 238 files | `com.example.saiflive` - the live-conversation host written for SAIF AI |

The last row deserves its own note. The `automation` module carried a separate
licence (TAMCL v1.0, Tech GPTx) and was the engine behind live conversation,
offline speech recognition and screen sharing. It was not optional - fifty
call sites across nine files depended on it - so removing it meant writing
SAIF AI's own session host, screen-capture controller, speech-model wrapper
and voice lock. That is what `com.example.saiflive` is.


## 3. Where this stands now

| | files | lines |
|---|---|---|
| Original SAIF AI code (never existed upstream) | **403** | — |
| Files sharing a path with an upstream file | 17 | ~640 |
| — identical to upstream (>=95%) | **0** | **0** |
| — modified from upstream (60-95%) | **0** | **0** |
| Highest similarity to any upstream file | **0.455** | |

All 17 remaining files are build configuration, the application manifest, or
standard Android resource files. The highest-scoring one is a nine-line
adaptive-icon wrapper whose element set is fixed by the Android platform.

What similarity remains is shared vocabulary - manifest tag names, Gradle DSL
keywords, XML declarations - not shared expression. There is no remaining file
that could be called a copy, and none that could be called a modification.


## 4. What this means

**SAIF AI is not a derivative work of AntiGem.** No GPL v3 obligation arises
from the application source.

That conclusion rests on the measurement above, not on intent. It should be
re-measured whenever a large body of code enters the tree:

```bash
python3 tools/licence/provenance.py --upstream /tmp/upstream-antigem --write
```

If the "identical" or "modified" counts ever stop being zero, this file and
`LICENSE` have to be revisited before the app is distributed.


## 5. Third-party components that remain

The application links open-source libraries. Their licences are listed in
`THIRD_PARTY_NOTICES.md`. Two of them are copyleft and were checked
specifically, because the obvious reading of both is wrong:

- **`org.scilab.forge:jlatexmath`** is GPL-2.0-or-later **with the Classpath
  Exception**. Its own licence text states that linking it with independent
  modules does not place the combined work under the GPL. SAIF AI is an
  independent module. The notice and licence must ship with the app.
- **`com.github.termux.termux-app:terminal-emulator`** comes from a repository
  that is GPL-3.0-only, but that repository explicitly exempts its
  `terminal-emulator` library and documents it as **Apache-2.0**. SAIF AI
  depends on that library and nothing else from Termux, so no GPL-3.0
  obligation arises.

Neither makes the application a derivative work that must be published under
the GPL. `SHIPPING_CHECKLIST.md` records what each of them does require.


## 6. The guard rails

Three tools keep this honest, because a licence claim nobody checks drifts:

| Tool | What it does |
|---|---|
| `tools/licence/provenance.py` | Compares the tree against an upstream checkout and writes `saif_owned_files.txt` (originals) and `upstream_derived_files.txt` (comparable, with similarity scores) |
| `tools/licence/add_saif_headers.py` | Stamps the SAIF AI copyright notice on original files; reports an error if any original file is left unstamped, or if a file with no upstream counterpart carries the wrong notice |
| `tools/licence/upstream_derived_files.txt` | Checked in, so a regression shows up as a diff rather than as a surprise |

Run both before every release.


## 7. Honest limits

- The measurement is **path and content based**. It cannot detect an idea
  copied without the words. Rewriting a borrowed design in different variable
  names would not show up here. It was not done, but the tool would not prove
  that either way.
- Third-party licences are recorded as their projects declare them. If an
  upstream project relicenses, this file has to be updated by hand.
- This is an engineering audit, not legal advice. Anyone distributing the app
  commercially should have a lawyer read `LICENSE` and
  `THIRD_PARTY_NOTICES.md`.
