/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent

import android.content.Context

/**
 * Settings for SAIF AI's own agent runtime.
 *
 * Kept in their own preference file so nothing here can be disturbed by the rest of the app's
 * settings, and so a future version can move them without a migration puzzle.
 */
object AgentPrefs {

    private const val PREFS = "saif_agent"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_WORKSPACE = "workspace_dir"
    private const val KEY_AUTO_APPROVE = "auto_approve"
    private const val KEY_MAX_STEPS = "max_steps"
    private const val KEY_SEARCH_ENDPOINT = "search_endpoint"

    private const val DEFAULT_WORKSPACE = "agent-workspace"
    private const val DEFAULT_MAX_STEPS = 24

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Off until the user turns it on: the runtime should never surprise anyone by acting. */
    var enabled: Boolean
        get() = store?.getBoolean(KEY_ENABLED, false) ?: false
        set(value) { store?.edit()?.putBoolean(KEY_ENABLED, value)?.apply() }

    /** Folder name inside the app's private files directory. */
    var workspaceDir: String
        get() = store?.getString(KEY_WORKSPACE, DEFAULT_WORKSPACE) ?: DEFAULT_WORKSPACE
        set(value) { store?.edit()?.putString(KEY_WORKSPACE, value.trim().ifBlank { DEFAULT_WORKSPACE })?.apply() }

    /** When on, tools that change the device run without asking. Off by default, on purpose. */
    var autoApprove: Boolean
        get() = store?.getBoolean(KEY_AUTO_APPROVE, false) ?: false
        set(value) { store?.edit()?.putBoolean(KEY_AUTO_APPROVE, value)?.apply() }

    var maxSteps: Int
        get() = store?.getInt(KEY_MAX_STEPS, DEFAULT_MAX_STEPS) ?: DEFAULT_MAX_STEPS
        set(value) { store?.edit()?.putInt(KEY_MAX_STEPS, value.coerceIn(1, 100))?.apply() }

    /** Optional endpoint for `web_search`. Blank means the tool tells the model it is unavailable. */
    var searchEndpoint: String
        get() = store?.getString(KEY_SEARCH_ENDPOINT, "") ?: ""
        set(value) { store?.edit()?.putString(KEY_SEARCH_ENDPOINT, value.trim())?.apply() }

    @Volatile
    private var store: android.content.SharedPreferences? = null

    fun init(context: Context) {
        store = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }
}
