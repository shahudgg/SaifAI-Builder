/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.TimeUnit

/** A project folder the workspace knows about. */
data class ProjectItem(
    val name: String,
    val path: String,
    val isCustom: Boolean = false
)

/** A file open in the editor, with enough state to detect an edit and a conflict. */
data class OpenTab(
    val path: String,
    val name: String,
    val content: String = "",
    val originalContent: String = "",
    val isModified: Boolean = false,
    val isDiff: Boolean = false,
    val diffFile: String? = null,
    val isStagedDiff: Boolean = false,
    val commitHash: String? = null,
    val isReadOnly: Boolean = false,
    val originalHash: String = "",
    val diskConflict: Boolean = false,
    val diskContentOnConflict: String = "",
    val isExternal: Boolean = false
)

/** The result of a git action, with the message the UI shows when it fails. */
data class GitActionResult(val success: Boolean, val message: String = "")

/** Stable hash used to tell "changed on disk" from "changed in the editor". */
fun computeSha256(content: String): String =
    MessageDigest.getInstance("SHA-256").digest(content.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

/**
 * Combines the projects the workspace knows about into one de-duplicated list.
 *
 * Paths are compared after normalisation, because the same folder arrives as `/root/app` from one
 * source and `/root/app/` from another, and showing it twice is worse than the cost of normalising.
 */
fun mergeProjects(
    conversations: List<Conversation> = emptyList(),
    daemonProjects: List<ProjectItem> = emptyList(),
    activeProject: ProjectItem? = null
): List<ProjectItem> {
    val list = mutableListOf<ProjectItem>()
    val seen = mutableSetOf<String>()

    fun add(item: ProjectItem) {
        val key = normalizePath(item.path)
        if (key.isBlank() || !seen.add(key)) return
        list.add(item)
    }

    activeProject?.let { add(it) }
    daemonProjects.forEach { add(it) }
    conversations
        .mapNotNull { it.workspaceUri.takeIf { uri -> uri.isNotBlank() } }
        .forEach { path ->
            add(ProjectItem(name = path.substringAfterLast('/').ifBlank { path }, path = path))
        }

    return list.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
}

private fun normalizePath(path: String): String {
    val trimmed = path.trim().trimEnd('/')
    return if (trimmed.isEmpty()) "" else trimmed.lowercase(Locale.US)
}

/**
 * Client for SAIF AI's local workspace server.
 *
 * Written from scratch, talking JSON over HTTP on loopback. The server is optional — the app works
 * without it and the editor simply has no remote projects — so every call is fail-soft: a transport
 * problem yields `null` or `false` rather than an exception, which is what the callers expect.
 */
object IdeApiClient {

    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    private fun base(): String = AuthPreferences.currentBridgeHttpUrl.trimEnd('/')

    /** True when the local workspace server answers. */
    suspend fun checkHealth(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            http.newCall(Request.Builder().url("${base()}/ping").get().build())
                .execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    /** Projects the server knows about. */
    suspend fun getProjects(): List<ProjectItem> = withContext(Dispatchers.IO) {
        runCatching {
            val body = http.newCall(Request.Builder().url("${base()}/projects").get().build())
                .execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    response.body?.string().orEmpty()
                }
            val array = org.json.JSONArray(body)
            (0 until array.length()).mapNotNull { i ->
                val obj = array.optJSONObject(i) ?: return@mapNotNull null
                ProjectItem(
                    name = obj.optString("name"),
                    path = obj.optString("path"),
                    isCustom = obj.optBoolean("isCustom", false)
                )
            }
        }.getOrDefault(emptyList())
    }

    /** The stored MCP configuration as raw JSON, or null when the server has none. */
    suspend fun getMcpConfig(): String? = withContext(Dispatchers.IO) {
        runCatching {
            http.newCall(Request.Builder().url("${base()}/mcp/config").get().build())
                .execute().use { response ->
                    if (!response.isSuccessful) null else response.body?.string()
                }
        }.getOrNull()
    }

    /** Writes the MCP configuration. False when the server is unreachable. */
    suspend fun saveMcpConfig(configJson: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            http.newCall(
                Request.Builder()
                    .url("${base()}/mcp/config")
                    .put(configJson.toRequestBody(json))
                    .build()
            ).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    /** Reads a file through the server, so paths outside the app's sandbox are reachable. */
    suspend fun readFile(path: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = java.net.URLEncoder.encode(path, "UTF-8")
            http.newCall(Request.Builder().url("${base()}/files?path=$encoded").get().build())
                .execute().use { response ->
                    if (!response.isSuccessful) null else response.body?.string()
                }
        }.getOrNull()
    }

    /** Writes a file through the server. */
    suspend fun saveFile(path: String, content: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("path", path).put("content", content).toString()
            http.newCall(
                Request.Builder().url("${base()}/files").post(payload.toRequestBody(json)).build()
            ).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }
}

/**
 * Git operations, run against the local workspace server when it is up and against the device's own
 * `git` binary when it is not.
 *
 * The fallback matters: git identity configuration is a one-line write, and refusing to do it
 * because a server is down would leave the user unable to commit at all.
 */
object GitApiClient {

    suspend fun setConfig(
        projectPath: String,
        userName: String? = null,
        userEmail: String? = null,
        pullRebase: String? = null,
        remoteUrl: String? = null,
        isGlobal: Boolean = false
    ): GitActionResult = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("project", projectPath)
            if (userName != null) put("userName", userName)
            if (userEmail != null) put("userEmail", userEmail)
            if (pullRebase != null) put("pullRebase", pullRebase)
            if (remoteUrl != null) put("remoteUrl", remoteUrl)
            put("isGlobal", isGlobal)
        }
        runCatching {
            val response = IdeApiClient.let { client ->
                val request = Request.Builder()
                    .url("${AuthPreferences.currentBridgeHttpUrl.trimEnd('/')}/git/config")
                    .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()
                client
                request
            }
            OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).build()
                .newCall(response).execute().use {
                    if (it.isSuccessful) GitActionResult(true)
                    else GitActionResult(false, "The local server returned HTTP ${it.code}")
                }
        }.getOrElse { GitActionResult(false, it.message ?: "Could not reach the local server.") }
    }

    /** Reads the configured git identity, falling back to the device's own git when possible. */
    suspend fun getConfig(projectPath: String): Pair<String, String> = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = java.net.URLEncoder.encode(projectPath, "UTF-8")
            val body = OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).build()
                .newCall(
                    Request.Builder()
                        .url("${AuthPreferences.currentBridgeHttpUrl.trimEnd('/')}/git/config?project=$encoded")
                        .get().build()
                ).execute().use { if (!it.isSuccessful) null else it.body?.string() }
            val obj = body?.let { JSONObject(it) }
            (obj?.optString("userName").orEmpty()) to (obj?.optString("userEmail").orEmpty())
        }.getOrDefault("" to "")
    }
}

/**
 * Tracks the workspace daemon's health and the editor's open tabs.
 *
 * Written from scratch and much smaller than the surface it replaces: it holds the state the UI
 * needs (status, active project, open tabs) and refreshes it from [IdeApiClient]. Nothing here
 * starts a process or manages a connection — that belongs to the environment manager.
 */
object TermuxDaemonManager {

    private const val PREFS = "saif_daemon"

    private val _status = MutableStateFlow(DaemonStatus.STOPPED)
    val status: StateFlow<DaemonStatus> = _status.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _projects = MutableStateFlow<List<ProjectItem>>(emptyList())
    val projects: StateFlow<List<ProjectItem>> = _projects.asStateFlow()

    private val _activeProject = MutableStateFlow<ProjectItem?>(null)
    val activeProject: StateFlow<ProjectItem?> = _activeProject.asStateFlow()

    private val _activeTabPath = MutableStateFlow<String?>(null)
    val activeTabPath: StateFlow<String?> = _activeTabPath.asStateFlow()

    private val _openTabs = MutableStateFlow<List<OpenTab>>(emptyList())
    val openTabs: StateFlow<List<OpenTab>> = _openTabs.asStateFlow()

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val name = prefs.getString("active_proj_name", null)
        val path = prefs.getString("active_proj_path", null)
        if (!name.isNullOrBlank() && !path.isNullOrBlank()) {
            _activeProject.value = ProjectItem(name = name, path = path)
        }
    }

    /**
     * Makes sure something is answering on the bridge address before anything asks it a question.
     *
     * The daemon is bundled with the app now, so "the server is not running" is no longer something
     * the user has to fix by installing Linux and waiting for a download; it is usually just a
     * process that has not been started yet. Starting it here means every path into the workspace
     * — opening the editor, listing projects, checking sign-in — repairs itself instead of
     * reporting a dead end.
     */
    private suspend fun ensureDaemon() {
        if (IdeApiClient.checkHealth()) return
        val context = appContext ?: return
        val url = SaifDaemon.ensureRunning(context)
        if (url != null) {
            log("Workspace daemon ready at $url")
        } else {
            log(SaifDaemon.lastError() ?: "The workspace daemon could not be started.")
        }
    }

    /** Re-reads the project list and reports whether the daemon answered. */
    suspend fun loadProjects(conversations: List<Conversation> = emptyList()): List<ProjectItem> =
        withContext(Dispatchers.IO) {
            _status.value = DaemonStatus.STARTING
            ensureDaemon()
            val healthy = IdeApiClient.checkHealth()
            val daemonList = if (healthy) IdeApiClient.getProjects() else emptyList()
            val merged = mergeProjects(conversations, daemonList, _activeProject.value)
            _projects.value = merged
            _status.value = if (healthy) DaemonStatus.RUNNING else DaemonStatus.STOPPED
            _statusMessage.value = when {
                healthy -> "Connected"
                SaifDaemon.lastError() != null -> SaifDaemon.lastError()!!
                else -> "The local workspace server is not running."
            }
            merged
        }

    /** Re-checks the daemon and reloads when it came back. */
    suspend fun checkHealthAndReconnect() {
        ensureDaemon()
        val healthy = IdeApiClient.checkHealth()
        if (healthy && _status.value != DaemonStatus.RUNNING) {
            loadProjects()
        } else if (!healthy) {
            _status.value = DaemonStatus.STOPPED
        }
    }

    fun setActiveProject(project: ProjectItem?) {
        _activeProject.value = project
    }

    fun setActiveTabPath(path: String?) {
        _activeTabPath.value = path
    }

    fun setOpenTabs(tabs: List<OpenTab>) {
        _openTabs.value = tabs
    }

    /** Opens [path] as a tab, or selects it when it is already open. */
    fun openOrSelectTab(path: String): OpenTab {
        val existing = _openTabs.value.firstOrNull { it.path == path }
        if (existing != null) {
            _activeTabPath.value = path
            return existing
        }
        val content = runCatching { File(path).readText() }.getOrDefault("")
        val tab = OpenTab(
            path = path,
            name = path.substringAfterLast('/'),
            content = content,
            originalContent = content,
            originalHash = computeSha256(content)
        )
        _openTabs.value = _openTabs.value + tab
        _activeTabPath.value = path
        return tab
    }

    fun updateTabContent(path: String, newContent: String) {
        _openTabs.value = _openTabs.value.map { tab ->
            if (tab.path != path) tab
            else tab.copy(
                content = newContent,
                isModified = computeSha256(newContent) != tab.originalHash
            )
        }
    }

    fun markTabSaved(path: String, newHash: String = "") {
        _openTabs.value = _openTabs.value.map { tab ->
            if (tab.path != path) tab
            else {
                val hash = newHash.ifBlank { computeSha256(tab.content) }
                tab.copy(originalContent = tab.content, originalHash = hash, isModified = false)
            }
        }
    }

    /** Compares an open tab with the file on disk and reports what should happen. */
    fun updateTabFromDisk(path: String, diskContent: String, diskHash: String = ""): TabDiskUpdateResult {
        val hash = diskHash.ifBlank { computeSha256(diskContent) }
        var result = TabDiskUpdateResult.NO_CHANGE
        _openTabs.value = _openTabs.value.map { tab ->
            if (tab.path != path) return@map tab
            if (hash == tab.originalHash) return@map tab
            if (!tab.isModified) {
                result = TabDiskUpdateResult.RELOADED
                tab.copy(
                    content = diskContent,
                    originalContent = diskContent,
                    originalHash = hash,
                    isModified = false,
                    diskConflict = false
                )
            } else {
                result = TabDiskUpdateResult.CONFLICT
                tab.copy(diskConflict = true, diskContentOnConflict = diskContent)
            }
        }
        return result
    }

    /** Resolves a conflict in favour of one side or the other. */
    fun resolveTabConflict(path: String, keepMine: Boolean) {
        _openTabs.value = _openTabs.value.map { tab ->
            if (tab.path != path || !tab.diskConflict) return@map tab
            val content = if (keepMine) tab.content else tab.diskContentOnConflict
            tab.copy(
                content = content,
                originalContent = content,
                originalHash = computeSha256(content),
                isModified = false,
                diskConflict = false,
                diskContentOnConflict = ""
            )
        }
    }

    fun log(message: String) {
        _logs.value = (_logs.value + message).takeLast(300)
    }
}
