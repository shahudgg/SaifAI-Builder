/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream

/**
 * SAIF AI's own Linux environment manager.
 *
 * Written from scratch. The job is narrow and mechanical: put a working Linux userland inside the
 * app's private files, keep a record of whether it verified, and tell the UI what is happening while
 * that takes several minutes.
 *
 * Three decisions shape it:
 *
 *  - **Everything lives under `filesDir/usr`.** No root, no external storage, no shared prefix — so
 *    the environment belongs to this app and is removed with it.
 *  - **Install runs in the background and is idempotent.** It can be requested from a dozen places
 *    at once; only the first does the work, and the rest observe the same state.
 *  - **A verified environment is a separate flag from an installed one.** Extraction succeeding is
 *    not proof the binaries run, so the app verifies once and remembers, instead of re-checking on
 *    every launch.
 */
object LocalEnvironmentManager {

    private const val NOTIFICATION_CHANNEL_ID = "saif_linux_setup"
    private const val NOTIFICATION_ID = 4101

    /** Version recorded with the install; bumping it forces a fresh setup. */
    private const val ENVIRONMENT_VERSION = "1"

    private val _installerState = MutableStateFlow<LocalInstallerState>(LocalInstallerState.Idle)
    val installerState: StateFlow<LocalInstallerState> = _installerState.asStateFlow()

    private val _installerLogs = MutableStateFlow<List<String>>(emptyList())
    val installerLogs: StateFlow<List<String>> = _installerLogs.asStateFlow()

    @Volatile
    private var installJobRunning = false

    // ---- Layout ------------------------------------------------------------------------------

    fun getPrefixDir(context: Context): File = File(context.filesDir, "usr")
    fun getBinDir(context: Context): File = File(getPrefixDir(context), "bin")
    fun getLibDir(context: Context): File = File(getPrefixDir(context), "lib")
    fun getEtcDir(context: Context): File = File(getPrefixDir(context), "etc")
    fun getTmpDir(context: Context): File = File(getPrefixDir(context), "tmp")
    fun getHomeDir(context: Context): File = File(context.filesDir, "home")
    fun getProjectsDir(context: Context): File = File(getHomeDir(context), "projects")
    fun getUbuntuRootDir(context: Context): File = File(context.filesDir, "ubuntu")

    fun isTermuxPackage(context: Context): Boolean = context.packageName == "com.termux"

    // ---- State -------------------------------------------------------------------------------

    /** True when a prefix exists and at least one expected binary is present. */
    fun isInstalled(context: Context): Boolean {
        val bin = getBinDir(context)
        return bin.isDirectory && (File(bin, "bash").exists() || File(bin, "sh").exists())
    }

    /** True when an install has both completed and passed a runtime check at least once. */
    fun hasVerifiedEnvironment(context: Context): Boolean {
        if (!isInstalled(context)) return false
        val prefs = context.applicationContext.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
        val recorded = prefs.getString(KEY_ENV_VERSION, null)
        return recorded == ENVIRONMENT_VERSION && prefs.getBoolean(KEY_ENV_VERIFIED, false)
    }

    fun markVerifiedEnvironment(context: Context) {
        context.applicationContext.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENV_VERIFIED, true)
            .putString(KEY_ENV_VERSION, ENVIRONMENT_VERSION)
            .apply()
    }

    // ---- Install -----------------------------------------------------------------------------

    /**
     * Installs the environment if it is not already there.
     *
     * Safe to call repeatedly and concurrently. Sign-in and chat never wait on this — they start
     * immediately and the environment becomes available when it is ready.
     */
    suspend fun ensureInstalledInBackground(context: Context) {
        val app = context.applicationContext
        if (hasVerifiedEnvironment(app) || installJobRunning) return
        synchronized(this) {
            if (installJobRunning) return
            installJobRunning = true
        }
        try {
            if (hasVerifiedEnvironment(app)) return
            _installerState.value = LocalInstallerState.Discovering
            log("Preparing the Linux environment…")

            val prefix = getPrefixDir(app)
            prefix.mkdirs()
            getHomeDir(app).mkdirs()
            getProjectsDir(app).mkdirs()
            getTmpDir(app).mkdirs()

            // proot ships inside the APK but assets cannot be executed, so it is unpacked once.
            // Nothing in the guest can run until this exists, so it goes first.
            installProot(app)

            val source = discoverBootstrap(app)
            if (source == null) {
                // No package available and nothing bundled: the app still works, just without a shell.
                log("No Linux package is available. The app will run without a local shell.")
                _installerState.value = LocalInstallerState.Done
                return
            }

            _installerState.value = LocalInstallerState.Downloading(0, source.sizeBytes)
            val archive = download(app, source)

            _installerState.value = LocalInstallerState.Extracting(0f)
            extract(archive, prefix)

            _installerState.value = LocalInstallerState.Configuring
            configure(app)

            _installerState.value = LocalInstallerState.Verifying
            val ok = verify(app)
            if (ok) {
                app.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_LOCAL_TOOLS_INSTALLED, true)
                    .putLong(KEY_LOCAL_TOOLS_INSTALL_DATE, System.currentTimeMillis())
                    .putString(KEY_LOCAL_TOOLS_VERSION, ENVIRONMENT_VERSION)
                    .apply()
                markVerifiedEnvironment(app)
                _installerState.value = LocalInstallerState.Done
                log("Linux environment ready.")
            } else {
                _installerState.value = LocalInstallerState.Error("The Linux tools did not start correctly.")
            }
        } catch (t: Throwable) {
            _installerState.value = LocalInstallerState.Error(t.message ?: "Setup failed.")
            log("Setup failed: ${t.message}")
        } finally {
            installJobRunning = false
        }
    }

    // ---- Steps -------------------------------------------------------------------------------

    private data class Bootstrap(val url: String, val sizeBytes: Long)

    /**
     * Finds something to install, in preference order: a cached download, a bundled asset, then the
     * network. Returns null when none is available, which is a valid outcome rather than an error.
     */
    /**
     * Finds something to install, in preference order: a cached download, a bundled asset, then the
     * network.
     *
     * The network address is a setting, not an environment variable. `System.getenv` always returns
     * null inside an Android app process, so the old version of this method could never find a
     * package at all — the download was simply never attempted, and everything downstream waited
     * forever for an environment that was never going to arrive. Reading the address from
     * preferences fixes that and lets a person point at a mirror or a different distribution.
     */
    private fun discoverBootstrap(context: Context): Bootstrap? {
        val cached = cachedArchive(context)
        if (cached != null) {
            log("Using the cached Linux package.")
            return Bootstrap("file://${cached.absolutePath}", cached.length())
        }

        val bundled = runCatching {
            context.assets.list("bootstrap").orEmpty()
                .firstOrNull { name -> ARCHIVE_EXTENSIONS.any { name.endsWith(it) } }
        }.getOrNull()
        if (bundled != null) {
            log("Using the bundled Linux package: $bundled")
            return Bootstrap("asset://bootstrap/$bundled", 0L)
        }

        val remote = context.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
            .getString(AuthPreferences.KEY_LINUX_PACKAGE_URL, null)
            ?.takeIf { it.isNotBlank() }
            ?: AuthPreferences.DEFAULT_LINUX_PACKAGE_URL
        if (!remote.startsWith("https://")) {
            log("The Linux package address is not an HTTPS URL, so nothing was downloaded.")
            return null
        }
        log("Downloading the Linux package…")
        return Bootstrap(remote, 0L)
    }

    private fun cachedArchive(context: Context): File? {
        val dir = File(context.filesDir, "bootstrap")
        return ARCHIVE_EXTENSIONS
            .map { ext -> File(dir, "bootstrap$ext") }
            .firstOrNull { it.isFile && it.length() > 0 }
    }

    /** Longest first, so ".tar.xz" wins over ".tar". */
    private fun extensionOf(name: String): String {
        val lower = name.substringBefore('?').lowercase(Locale.US)
        return ARCHIVE_EXTENSIONS.firstOrNull { lower.endsWith(it) } ?: ".zip"
    }

    private suspend fun download(context: Context, source: Bootstrap): File = withContext(Dispatchers.IO) {
        if (source.url.startsWith("file://")) {
            return@withContext File(source.url.removePrefix("file://"))
        }
        val out = if (source.url.startsWith("asset://")) {
            val name = source.url.removePrefix("asset://")
            File(context.filesDir, "bootstrap/bootstrap" + extensionOf(name))
        } else {
            File(context.filesDir, "bootstrap/bootstrap" + extensionOf(source.url))
        }
        out.parentFile?.mkdirs()

        when {
            source.url.startsWith("asset://") -> {
                val name = source.url.removePrefix("asset://")
                context.assets.open(name).use { input ->
                    FileOutputStream(out).use { input.copyTo(it) }
                }
                out
            }
            else -> {
                val connection = URL(source.url).openConnection() as HttpURLConnection
                try {
                    connection.connectTimeout = 20_000
                    connection.readTimeout = 60_000
                    connection.instanceFollowRedirects = true
                    connection.connect()
                    if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
                    val total = connection.contentLengthLong
                    connection.inputStream.use { input ->
                        FileOutputStream(out).use { fileOut ->
                            val buffer = ByteArray(64 * 1024)
                            var read: Int
                            var done = 0L
                            while (input.read(buffer).also { read = it } >= 0) {
                                fileOut.write(buffer, 0, read)
                                done += read
                                _installerState.value = LocalInstallerState.Downloading(done, total)
                            }
                        }
                    }
                } finally {
                    connection.disconnect()
                }
                out
            }
        }
    }

    private suspend fun extract(archive: File, target: File) = withContext(Dispatchers.IO) {
        target.mkdirs()
        val name = archive.name.lowercase(Locale.US)
        when {
            name.endsWith(".tar.xz") || name.endsWith(".txz") -> extractTar(archive, target, xz = true)
            name.endsWith(".tar.gz") || name.endsWith(".tgz") -> extractTar(archive, target, gzip = true)
            name.endsWith(".tar") -> extractTar(archive, target)
            else -> extractZip(archive, target)
        }
        // Some packagers wrap the filesystem in one folder; lifting it makes the layout identical
        // whichever archive was used, so nothing downstream has to know.
        liftSingleTopLevelDirectory(target)
        // Archives disagree about the executable bit, so it is set explicitly where it matters.
        markExecutable(File(target, "bin"))
        markExecutable(File(target, "sbin"))
        markExecutable(File(target, "usr/bin"))
        markExecutable(File(target, "usr/sbin"))
    }

    private fun extractZip(archive: File, target: File) {
        ZipInputStream(archive.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val destination = resolveSafe(target, entry.name) ?: continue
                if (entry.isDirectory) {
                    destination.mkdirs()
                } else {
                    destination.parentFile?.mkdirs()
                    FileOutputStream(destination).use { zip.copyTo(it) }
                }
                zip.closeEntry()
            }
        }
    }

    private fun extractTar(archive: File, target: File, xz: Boolean = false, gzip: Boolean = false) {
        val raw = archive.inputStream().buffered()
        val decompressed = when {
            xz -> XZCompressorInputStream(raw)
            gzip -> GzipCompressorInputStream(raw)
            else -> raw
        }
        TarArchiveInputStream(decompressed).use { tar ->
            while (true) {
                val entry = tar.nextEntry ?: break
                val destination = resolveSafe(target, entry.name) ?: continue
                if (entry.isDirectory) {
                    destination.mkdirs()
                } else {
                    destination.parentFile?.mkdirs()
                    FileOutputStream(destination).use { tar.copyTo(it) }
                }
            }
        }
    }

    /** Resolves an archive entry inside [target], or null for anything that would escape it. */
    private fun resolveSafe(target: File, rawName: String): File? {
        var name = rawName.replace('\\', '/').trimStart('/')
        while (name.startsWith("./")) name = name.removePrefix("./")
        if (name.isBlank()) return null
        val destination = File(target, name).canonicalFile
        val root = target.canonicalFile
        if (destination == root) return null
        if (!destination.path.startsWith(root.path + File.separator)) return null
        return destination
    }

    private fun liftSingleTopLevelDirectory(target: File) {
        val children = target.listFiles() ?: return
        if (children.size != 1 || !children[0].isDirectory) return
        val inner = children[0]
        // Only lift a real filesystem root; an ordinary top-level folder is left alone.
        if (!File(inner, "bin").isDirectory && !File(inner, "usr/bin").isDirectory) return
        inner.listFiles()?.forEach { child ->
            val destination = File(target, child.name)
            if (destination.exists()) destination.deleteRecursively()
            child.renameTo(destination)
        }
        inner.delete()
    }

    private fun markExecutable(dir: File) {
        if (!dir.isDirectory) return
        dir.listFiles()?.forEach { runCatching { it.setExecutable(true, true) } }
    }

    private fun configure(context: Context) {
        val etc = getEtcDir(context)
        etc.mkdirs()
        val profile = File(etc, "profile")
        val prefix = getPrefixDir(context).absolutePath
        profile.writeText(
            """
            export PREFIX=$prefix
            export HOME=$GUEST_HOME
            export TMPDIR=/tmp
            export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:${'$'}PATH
            export LD_LIBRARY_PATH=$prefix/lib:${'$'}LD_LIBRARY_PATH
            export LANG=C.UTF-8
            """.trimIndent()
        )
    }

    /**
     * Runs the shell itself, which is the only check that actually proves the install works.
     *
     * It has to run under proot. Android's kernel is Linux but its C library is Bionic, so a glibc
     * binary from a Debian rootfs cannot start on its own: its loader and library paths simply do
     * not exist here. proot translates them, which is the whole reason it ships with the app.
     */
    private suspend fun verify(context: Context): Boolean = withContext(Dispatchers.IO) {
        val rootfs = getPrefixDir(context)
        val shell = listOf("bin/bash", "bin/sh", "usr/bin/bash", "usr/bin/sh")
            .map { File(rootfs, it) }
            .firstOrNull { it.exists() } ?: return@withContext false
        runCatching { shell.setExecutable(true, true) }

        if (runInLinuxOk(context, listOf("/" + shell.relativeTo(rootfs).path, "-c", "echo ok"))) {
            return@withContext true
        }
        // A statically linked rootfs (musl, Alpine) starts without proot, so try it bare too.
        runCatching {
            val process = ProcessBuilder(shell.absolutePath, "-c", "echo ok")
                .directory(rootfs)
                .redirectErrorStream(true)
                .start()
            val out = StringBuilder()
            val drainer = Thread { runCatching { process.inputStream.bufferedReader().forEachLine { out.appendLine(it) } } }
                .apply { isDaemon = true; start() }
            val finished = process.waitFor(20, java.util.concurrent.TimeUnit.SECONDS)
            drainer.join(1_000)
            finished && process.exitValue() == 0
        }.getOrDefault(false)
    }

    private fun runInLinuxOk(context: Context, command: List<String>): Boolean = runCatching {
        val process = buildLinuxProcess(context, command).start()
        val drainer = Thread { runCatching { process.inputStream.bufferedReader().forEachLine { } } }
            .apply { isDaemon = true; start() }
        val finished = process.waitFor(30, java.util.concurrent.TimeUnit.SECONDS)
        drainer.join(1_000)
        if (!finished) {
            process.destroy()
            false
        } else {
            process.exitValue() == 0
        }
    }.getOrDefault(false)

    // ---- proot -------------------------------------------------------------------------------

    /**
     * Where proot lives. Deliberately outside the guest rootfs: the environment is downloaded and
     * re-extracted, and proot must survive that, nor should a guest program be able to replace it.
     */
    fun getProotDir(context: Context): File = File(context.filesDir, "proot-tools")

    private fun prootBinary(context: Context): File? {
        val file = File(getProotDir(context), "bin/proot")
        if (!file.exists()) return null
        runCatching { file.setExecutable(true, false) }
        return file
    }

    /**
     * Unpacks the proot that ships in the APK.
     *
     * Assets are entries in a zip, not files, and cannot be executed — so they are copied out once.
     * The whole bin/ + lib/ layout is preserved because proot locates its loader relative to
     * itself and needs libtalloc alongside it; copying only the one binary would leave a program
     * that starts and immediately fails.
     */
    private fun installProot(context: Context) {
        val target = getProotDir(context)
        val stamp = File(target, ".installed")
        if (stamp.exists() && File(target, "bin/proot").exists()) return
        val shipped = listOf("bin/proot", "bin/loader", "bin/libtalloc.so.2", "lib/libtalloc.so.2")
        var copied = 0
        shipped.forEach { name ->
            val out = File(target, name)
            runCatching {
                out.parentFile?.mkdirs()
                context.assets.open(name).use { input ->
                    FileOutputStream(out).use { input.copyTo(it) }
                }
                out.setExecutable(true, false)
                out.setReadable(true, false)
                copied++
            }.onFailure { error -> log("Could not unpack $name: ${error.message}") }
        }
        if (copied > 0) {
            runCatching { stamp.writeText(ENVIRONMENT_VERSION) }
            log("proot is ready ($copied files unpacked).")
        }
    }

    private fun prootEnvironment(context: Context): Map<String, String> {
        val tools = getProotDir(context)
        val environment = HashMap(System.getenv())
        environment["PROOT_LOADER"] = File(tools, "bin/loader").absolutePath
        environment["LD_LIBRARY_PATH"] = File(tools, "lib").absolutePath
        environment["PROOT_TMP_DIR"] = getTmpDir(context).absolutePath
        // A guest path, because the app's home directory is bound at /home inside the sandbox and
        // an Android path would be resolved against the guest root instead.
        environment["HOME"] = GUEST_HOME
        environment["LANG"] = "C.UTF-8"
        return environment
    }

    /**
     * Builds a process that runs [command] inside the Linux environment.
     *
     * This is the single place that knows how a guest binary is started, so the terminal, the
     * provider launchers and the verification step all behave the same way.
     */
    fun buildLinuxProcess(context: Context, command: List<String>, workDir: String = "/"): ProcessBuilder {
        val rootfs = getPrefixDir(context)
        val proot = prootBinary(context)
        return if (proot != null) {
            val argv = ArrayList<String>()
            argv.add(proot.absolutePath)
            argv.add("-r"); argv.add(rootfs.absolutePath)
            argv.add("-b"); argv.add("/dev")
            argv.add("-b"); argv.add("/proc")
            argv.add("-b"); argv.add("/sys")
            argv.add("-b"); argv.add("/sdcard")
            // The workspace lives in the app's private storage; binding it means files written in
            // a terminal session are the same files the editor and the agent see.
            argv.add("-b"); argv.add(getHomeDir(context).absolutePath + ":" + GUEST_HOME)
            argv.add("-w"); argv.add(workDir)
            argv.add("--kill-on-exit")
            argv.addAll(command)
            ProcessBuilder(argv).apply {
                environment().putAll(prootEnvironment(context))
            }
        } else {
            ProcessBuilder(command).apply {
                environment()["HOME"] = getHomeDir(context).absolutePath
                environment()["TMPDIR"] = getTmpDir(context).absolutePath
                environment()["LANG"] = "C.UTF-8"
            }
        }.apply {
            directory(rootfs)
            // Merged so a failing command cannot wedge itself on a full error pipe.
            redirectErrorStream(true)
        }
    }

    // ---- Reporting ---------------------------------------------------------------------------

    fun log(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = "$time  $message"
        _installerLogs.value = (_installerLogs.value + entry).takeLast(400)
    }

    fun clearLogs() {
        _installerLogs.value = emptyList()
    }

    /** Shows setup progress in the notification shade, since it runs for minutes at a time. */
    private fun notify(context: Context, title: String, text: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Linux setup",
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        runCatching { manager.notify(NOTIFICATION_ID, notification) }
    }

    /** Where the app's home directory appears inside the Linux environment. */
    private const val GUEST_HOME = "/home"

    /** Archive suffixes a rootfs is ever published in. Longest first, so ".tar.xz" beats ".tar". */
    private val ARCHIVE_EXTENSIONS = listOf(".tar.xz", ".tar.gz", ".tgz", ".txz", ".tar", ".zip")

    private const val KEY_ENV_VERIFIED = "linux_env_verified"
    private const val KEY_ENV_VERSION = "linux_env_version"
    private const val KEY_LOCAL_TOOLS_INSTALLED = "local_tools_installed"
    private const val KEY_LOCAL_TOOLS_INSTALL_DATE = "local_tools_install_date"
    private const val KEY_LOCAL_TOOLS_VERSION = "local_tools_version"
}

/**
 * Starts, and stops, the parts of the environment that belong to a signed-in account.
 *
 * The environment itself is shared; what is per-account is the home and projects layout. Signing out
 * therefore does not delete anything — it just stops the per-account work until someone signs in
 * again, so a sign-out can never destroy a user's files.
 */
object AuthenticatedWorkspace {

    @Volatile
    private var started = false

    suspend fun ensureStarted(context: Context) {
        if (started) return
        val app = context.applicationContext
        LocalEnvironmentManager.getHomeDir(app).mkdirs()
        LocalEnvironmentManager.getProjectsDir(app).mkdirs()
        started = true
        LocalEnvironmentManager.log("Workspace ready at ${LocalEnvironmentManager.getHomeDir(app)}")

        // The environment is only prepared for a signed-in account; installation runs in the
        // background and never blocks the UI.
        LocalEnvironmentManager.ensureInstalledInBackground(app)
    }

    fun onSignedOut() {
        started = false
    }
}

/**
 * Starts and stops SAIF AI's local HTTP server.
 *
 * Kept deliberately simple: the server is one component with no dependencies, so "restart" is
 * literally stop-then-start with a short pause, and any failure is reported rather than retried
 * forever.
 */
object LocalServerManager {

    /**
     * Restarts the local server.
     *
     * Not suspend, because it is called straight from a click handler: the work goes onto the IO
     * dispatcher and the caller carries on. A restart that fails is logged, never thrown.
     */
    fun restartServer(context: Context) {
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            LocalEnvironmentManager.log("Restarting the local server…")
            runCatching { AndroidLocalBridgeServer.instance.stop() }
            runCatching { Thread.sleep(300) }
            runCatching { AndroidLocalBridgeServer.instance.start(context.applicationContext) }
                .onFailure { LocalEnvironmentManager.log("Could not restart the local server: ${it.message}") }
        }
    }
}
