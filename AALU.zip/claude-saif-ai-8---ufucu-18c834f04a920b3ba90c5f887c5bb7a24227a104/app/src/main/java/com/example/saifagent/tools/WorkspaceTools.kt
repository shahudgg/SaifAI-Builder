/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent.tools

import com.example.saifagent.AgentTool
import com.example.saifagent.ToolContext
import com.example.saifagent.ToolOutcome
import com.example.saifagent.ToolParam
import com.example.saifagent.optionalString
import com.example.saifagent.requireString
import org.json.JSONObject
import java.io.File

/**
 * File tools for SAIF AI's own agent runtime.
 *
 * Every path is resolved against the workspace root and checked to stay inside it, so a model that
 * asks for `../../etc/passwd` gets a refusal rather than a file. Binary files are refused by content
 * sniff, not by extension, because extensions lie.
 */
private fun ToolContext.resolve(rawPath: String): File {
    val root = workspace.canonicalFile
    val candidate = File(root, rawPath).canonicalFile
    require(candidate == root || candidate.path.startsWith(root.path + File.separator)) {
        "path '$rawPath' is outside the workspace"
    }
    return candidate
}

private const val MAX_READ_CHARS = 200_000
private const val MAX_LIST_ENTRIES = 400

class ReadFileTool : AgentTool {
    override val name = "read_file"
    override val description = "Read a UTF-8 text file from the workspace and return its contents."
    override val params = listOf(
        ToolParam("path", "Path relative to the workspace root."),
        ToolParam("max_chars", "Optional maximum number of characters to return.", "number", false)
    )

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val file = ctx.resolve(args.requireString("path"))
        val limit = args.opt("max_chars")?.toString()?.toLongOrNull() ?: MAX_READ_CHARS.toLong()
        if (!file.exists()) return ToolOutcome.fail("no such file: ${file.relativeTo(ctx.workspace)}")
        if (file.isDirectory) return ToolOutcome.fail("${file.name} is a directory, not a file")
        if (file.length() > 20L * 1024 * 1024) return ToolOutcome.fail("file is larger than 20 MB")
        val text = file.readText()
        if (text.contains('\u0000')) return ToolOutcome.fail("file looks binary, refusing to read it")
        ctx.log("read ${file.name} (${text.length} chars)")
        return ToolOutcome.ok(if (text.length <= limit) text else text.take(limit.toInt()) + "\n… truncated")
    }
}

class WriteFileTool : AgentTool {
    override val name = "write_file"
    override val description = "Create or overwrite a text file in the workspace. Parent folders are created."
    override val params = listOf(
        ToolParam("path", "Path relative to the workspace root."),
        ToolParam("content", "The full new contents of the file.")
    )
    override val needsApproval = true

    override fun summary(args: JSONObject) = "write ${args.optionalString("path")}"

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val file = ctx.resolve(args.requireString("path"))
        val content = args.requireString("content")
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, ".${file.name}.saif-tmp")
        tmp.writeText(content)
        if (!tmp.renameTo(file)) {
            file.writeText(content)
            tmp.delete()
        }
        ctx.log("wrote ${file.name} (${content.length} chars)")
        return ToolOutcome.ok("wrote ${file.relativeTo(ctx.workspace)} (${content.length} characters)")
    }
}

class ListDirTool : AgentTool {
    override val name = "list_dir"
    override val description = "List files and folders in a workspace directory."
    override val params = listOf(
        ToolParam("path", "Directory relative to the workspace root. Use '.' for the root.", "string", false)
    )

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val dir = ctx.resolve(args.optionalString("path", "."))
        if (!dir.exists()) return ToolOutcome.fail("no such directory: ${args.optionalString("path", ".")}")
        if (!dir.isDirectory) return ToolOutcome.fail("not a directory")
        val entries: List<File> = (dir.listFiles() ?: emptyArray())
            .toList()
            .sortedWith(compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() })
        if (entries.isEmpty()) return ToolOutcome.ok("(empty directory)")
        val shown = entries.take(MAX_LIST_ENTRIES)
        val body = shown.joinToString("\n") {
            val size = if (it.isDirectory) "<dir>" else "${it.length()} B"
            "${if (it.isDirectory) "d" else "f"}  ${it.relativeTo(ctx.workspace).path}  $size"
        }
        val tail = if (entries.size > MAX_LIST_ENTRIES) "\n… ${entries.size - MAX_LIST_ENTRIES} more" else ""
        return ToolOutcome.ok(body + tail)
    }
}

class SearchTool : AgentTool {
    override val name = "search_text"
    override val description =
        "Search the workspace for a literal string or simple substring and return matching file paths with line numbers."
    override val params = listOf(
        ToolParam("query", "The text to search for."),
        ToolParam("path", "Optional subdirectory to search.", "string", false),
        ToolParam("max_results", "Optional cap on results.", "number", false)
    )

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val query = args.requireString("query")
        if (query.isBlank()) return ToolOutcome.fail("query is empty")
        val root = ctx.resolve(args.optionalString("path", "."))
        val cap = args.opt("max_results")?.toString()?.toIntOrNull() ?: 60
        val hits = mutableListOf<String>()
        val skipDirs = setOf(".git", "build", "node_modules", ".gradle", "captures")
        root.walkTopDown()
            .onEnter { it.name !in skipDirs }
            .filter { it.isFile && it.length() < 2L * 1024 * 1024 }
            .forEach { file ->
                if (hits.size >= cap) return@forEach
                file.useLines { lines ->
                    lines.forEachIndexed { index, line ->
                        if (line.contains(query, ignoreCase = true)) {
                            hits.add("${file.relativeTo(ctx.workspace).path}:${index + 1}: ${line.trim().take(200)}")
                            if (hits.size >= cap) return@forEachIndexed
                        }
                    }
                }
            }
        if (hits.isEmpty()) return ToolOutcome.ok("no matches for \"$query\"")
        return ToolOutcome.ok(hits.joinToString("\n") + if (hits.size >= cap) "\n… result cap reached" else "")
    }
}

class DeleteFileTool : AgentTool {
    override val name = "delete_file"
    override val description = "Delete a file inside the workspace. Refuses directories."
    override val params = listOf(ToolParam("path", "Path relative to the workspace root."))
    override val needsApproval = true

    override fun summary(args: JSONObject) = "delete ${args.optionalString("path")}"

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val file = ctx.resolve(args.requireString("path"))
        if (!file.exists()) return ToolOutcome.fail("no such file")
        if (file.isDirectory) return ToolOutcome.fail("refusing to delete a directory")
        val deleted = file.delete()
        ctx.log("deleted ${file.name}")
        return if (deleted) ToolOutcome.ok("deleted ${file.relativeTo(ctx.workspace)}")
        else ToolOutcome.fail("could not delete the file")
    }
}

class MakeDirTool : AgentTool {
    override val name = "make_dir"
    override val description = "Create a directory inside the workspace."
    override val params = listOf(ToolParam("path", "Path relative to the workspace root."))
    override val needsApproval = true

    override fun summary(args: JSONObject) = "create folder ${args.optionalString("path")}"

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val dir = ctx.resolve(args.requireString("path"))
        if (dir.exists()) return ToolOutcome.ok("already exists")
        return if (dir.mkdirs()) ToolOutcome.ok("created ${dir.relativeTo(ctx.workspace)}")
        else ToolOutcome.fail("could not create the directory")
    }
}
