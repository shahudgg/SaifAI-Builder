/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Owns the lifetime of a live conversation.
 *
 * The service exists for one reason: the microphone outlives any single screen. A conversation that
 * dies because the user opened Settings, rotated the phone, or switched to another app is not a
 * conversation, so capture lives here and the UI only observes it.
 *
 * The service does not know how to think. It asks the app for a [HostLiveTurnLoop], feeds it the
 * session's events, and publishes whatever the loop reports into [LiveSessionBus] for the UI.
 */
class LiveConversationService : Service(), HostLiveTurnListener {

    companion object {
        private const val TAG = "LiveConversationService"

        const val ACTION_START = "com.example.saiflive.action.START"
        const val ACTION_STOP = "com.example.saiflive.action.STOP"

        private const val CHANNEL_ID = "saif_live_session"
        private const val NOTIFICATION_ID = 4271

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        /**
         * The instance, when there is one.
         *
         * Held so the UI can widen the service's foreground type without a binder round trip.
         * Cleared on destroy, and every use re-checks [isRunning], so a stale reference cannot
         * resurrect a dead service.
         */
        @Volatile
        private var active: LiveConversationService? = null

        /**
         * Widens the running service to a media-projection foreground service.
         *
         * Android 14 refuses to hand out a MediaProjection unless the calling service declared that
         * type when it came to the foreground, so the type is widened just before capture starts and
         * narrowed again when it stops. Re-declaring the type on a running service is allowed and is
         * preferable to restarting it, which would blink the session out from under the user.
         */
        fun elevateToMediaProjection(): Boolean {
            val service = active ?: return false
            return runCatching { service.declareForeground(includeProjection = true); true }
                .onFailure { Log.w(TAG, "Could not widen the foreground service type", it) }
                .getOrDefault(false)
        }

        fun demoteFromMediaProjection() {
            val service = active ?: return
            runCatching { service.declareForeground(includeProjection = false) }
        }

        /**
         * The live instance, or null when the service is not running.
         *
         * Returning null instead of throwing is deliberate: the UI calls through to the service from
         * click handlers that can fire a frame after the session has already ended.
         */
        fun activeInstance(): LiveConversationService? =
            active?.takeIf { _isRunning.value }
    }

    private val binder = LocalBinder()

    /** The app-supplied half of the conversation. Null before the session starts. */
    private var turnLoop: HostLiveTurnLoop? = null

    private var startedForeground = false

    inner class LocalBinder : Binder() {
        fun service(): LiveConversationService = this@LiveConversationService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
        active = this
        LiveSessionBus.setServiceAlive(true)
        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSession()
                stopForegroundCompat()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> startSession()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopSession()
        if (active === this) active = null
        LiveSessionBus.setServiceAlive(false)
        _isRunning.value = false
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // A live conversation cannot survive its task: the microphone would keep running with no
        // way for the user to get back to it, which reads as a bug rather than a feature.
        stopSession()
        stopForegroundCompat()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    // -----------------------------------------------------------------------------------------
    // Session
    // -----------------------------------------------------------------------------------------

    private fun startSession() {
        declareForeground(includeProjection = false)
        if (turnLoop != null) return

        val factory = SaifLive.hostLiveTurnFactory
        if (factory == null) {
            LiveSessionBus.setError(
                LiveSessionError(
                    "LIVE SESSION NOT READY",
                    "The conversation engine has not finished starting. Try again in a moment.",
                    "LIVE_NOT_LINKED"
                )
            )
            LiveSessionBus.setSessionOn(false)
            return
        }

        val loop = try {
            factory.invoke(this, SaifLive.buildSystemPrompt(), this)
        } catch (e: Throwable) {
            Log.w(TAG, "Could not create the turn loop", e)
            null
        }
        if (loop == null) {
            LiveSessionBus.setError(
                LiveSessionError(
                    "LIVE SESSION COULD NOT START",
                    "The conversation engine could not be created.",
                    "LIVE_START_FAILED"
                )
            )
            LiveSessionBus.setSessionOn(false)
            return
        }

        turnLoop = loop
        ScreenShareController.setFrameConsumer { jpeg -> loop.onScreenFrame(jpeg) }
        LiveSessionBus.setSessionOn(true)
        if (!loop.start()) {
            // The loop reports the reason itself; the only thing left to do is not pretend to be live.
            LiveSessionBus.setSessionOn(false)
            turnLoop = null
        }
    }

    private fun stopSession() {
        ScreenShareController.setFrameConsumer(null)
        runCatching { ScreenShareController.stop() }
        runCatching { turnLoop?.stop() }
        turnLoop = null
        LiveSessionBus.setSessionOn(false)
    }

    /** Passed straight through to the loop; the service holds no state of its own for these. */
    fun setMicMuted(muted: Boolean) = runCatching { turnLoop?.setMicMuted(muted) }

    fun interrupt() = runCatching { turnLoop?.interrupt() }

    fun sendText(text: String) = runCatching { turnLoop?.sendText(text) }

    // -----------------------------------------------------------------------------------------
    // HostLiveTurnListener
    // -----------------------------------------------------------------------------------------

    override fun onState(state: LiveConversationState) = LiveSessionBus.setState(state)

    override fun onUserTranscript(text: String) = LiveSessionBus.setUserTranscript(text)

    override fun onAssistantTranscript(text: String) = LiveSessionBus.setAssistantTranscript(text)

    override fun onAudioLevel(level: Float) = LiveSessionBus.setAudioLevel(level)

    override fun onActivity() = Unit

    override fun onTurnCompleted(user: String, assistant: String) {
        SaifLive.recordTurn(user, assistant)
    }

    override fun onError(error: LiveSessionError) {
        LiveSessionBus.setError(error)
        // Some failures are recoverable mid-session (one bad transcription, one dropped provider
        // call), so the session stays up and the UI keeps the reason visible next to the orb.
        if (error.errorCode in FATAL_CODES) {
            stopSession()
            stopForegroundCompat()
            stopSelf()
        }
    }

    private val FATAL_CODES = setOf("MIC_PERMISSION_REQUIRED", "API_KEY_MISSING", "MIC_ERROR")

    // -----------------------------------------------------------------------------------------
    // Foreground plumbing
    // -----------------------------------------------------------------------------------------

    private fun declareForeground(includeProjection: Boolean) {
        val notification = buildNotification(includeProjection)
        if (!startedForeground) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(NOTIFICATION_ID, notification, foregroundType(includeProjection))
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            }.onFailure {
                // Falling back to the untyped overload keeps the session alive on devices whose
                // implementation rejects the type constant.
                runCatching { startForeground(NOTIFICATION_ID, notification) }
            }
            startedForeground = true
        } else {
            runCatching { startForeground(NOTIFICATION_ID, notification) }
        }
    }

    private fun foregroundType(includeProjection: Boolean): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (includeProjection && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            type
        } else {
            0
        }

    private fun stopForegroundCompat() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
        startedForeground = false
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Live conversation",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shown while SAIF AI is listening in a live conversation."
            setShowBadge(false)
        }
        runCatching { manager.createNotificationChannel(channel) }
    }

    private fun buildNotification(includeProjection: Boolean): Notification {
        val tapIntent = packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
            launch.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            PendingIntent.getActivity(
                this,
                1,
                launch,
                PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
            )
        }
        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, LiveConversationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
        )
        val text = if (includeProjection) "Listening, and watching your screen"
        else "Listening"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SAIF AI Live")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .apply { if (tapIntent != null) setContentIntent(tapIntent) }
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()
    }

    private fun immutableFlag(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
}
