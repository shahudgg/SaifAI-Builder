/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

import android.content.Context
import android.media.projection.MediaProjection
import android.util.DisplayMetrics
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.flow.StateFlow

/**
 * The front door to SAIF AI's live conversation.
 *
 * The UI talks only to this object; the actual work is split between a foreground service that owns
 * the microphone ([LiveConversationService]) and a turn loop the app supplies
 * ([HostLiveTurnLoop]). Keeping the three apart is what makes it possible to restart the service
 * without losing the conversation, and to change how a turn is answered without touching capture.
 *
 * The engine holds no API key of its own. [link] gives it a resolver that reads the provider the
 * user configured in Settings, so there is one key to manage and one place to revoke it.
 */
object SaifLive {

    private const val TAG = "SaifLive"

    // --- Host-supplied behaviour --------------------------------------------------------------

    /**
     * Builds the half of the conversation that thinks: given a context, a system prompt and a
     * listener, returns something that can run turns.
     *
     * Supplied by SAIF AI (`com.example.live.LiveTurnLoop`) so that live conversation and typed
     * chat share routing, key rotation and the phone-agent runtime instead of drifting apart.
     */
    var hostLiveTurnFactory: ((Context, String, HostLiveTurnListener) -> HostLiveTurnLoop)? = null

    /** True when the host can answer even with no provider key of its own (a connected workspace). */
    var hostCanRespondWithoutKey: (() -> Boolean)? = null

    /** Preferred speaking voice, or null to let the engine choose. */
    var hostVoiceResolver: (() -> String)? = null

    /** Recalled memory to weave into the system prompt, per feature. */
    var hostMemoryResolver: ((feature: String) -> String)? = null

    /** Whether the engine should follow the speaker's language automatically. */
    var hostAutoLanguageResolver: (() -> Boolean)? = null

    @Volatile
    private var apiResolver: (() -> LiveProviderConfig)? = null

    @Volatile
    private var settingsOpener: (() -> Unit)? = null

    /** Called once at application start to bind the engine to the app's Settings. */
    fun link(apiResolver: () -> LiveProviderConfig, openHostSettings: () -> Unit) {
        this.apiResolver = apiResolver
        this.settingsOpener = openHostSettings
    }

    fun currentApi(): LiveProviderConfig =
        try {
            apiResolver?.invoke()
        } catch (e: Throwable) {
            Log.w(TAG, "The host API resolver failed", e)
            null
        } ?: LiveProviderConfig(provider = "", apiKey = "", model = "")

    val isLinked: Boolean get() = apiResolver != null

    /** True when a conversation is possible without a key, because the workspace can answer. */
    fun hasHostLiveAgent(): Boolean =
        try {
            hostLiveTurnFactory != null && hostCanRespondWithoutKey?.invoke() == true
        } catch (e: Throwable) {
            Log.w(TAG, "The host availability check failed", e)
            false
        }

    fun openHostSettings() {
        runCatching { settingsOpener?.invoke() }
    }

    fun hostVoiceName(): String? = try { hostVoiceResolver?.invoke() } catch (_: Throwable) { null }

    fun hostMemory(feature: String): String =
        try {
            hostMemoryResolver?.invoke(feature).orEmpty()
        } catch (_: Throwable) {
            ""
        }

    fun hostAutoLanguage(): Boolean = try { hostAutoLanguageResolver?.invoke() ?: true } catch (_: Throwable) { true }

    /**
     * Called when the user changes provider or key.
     *
     * The next turn picks the new credentials up by itself, so all this does is clear an error that
     * was telling the user to go and add a key - they have just done exactly that.
     */
    fun onHostApiChanged() {
        val error = LiveSessionBus.error.value ?: return
        if (error.errorCode == "API_KEY_MISSING") LiveSessionBus.setError(null)
    }

    // --- State the UI observes ----------------------------------------------------------------

    val isLiveRunning: StateFlow<Boolean> = LiveSessionBus.isSessionOn
    val orbState: StateFlow<LiveConversationState> = LiveSessionBus.state
    val liveMode: StateFlow<LiveMode> = LiveSessionBus.mode
    val userTranscript: StateFlow<String> = LiveSessionBus.userTranscript
    val assistantTranscript: StateFlow<String> = LiveSessionBus.assistantTranscript
    val audioLevel: StateFlow<Float> = LiveSessionBus.audioLevel
    val liveError: StateFlow<LiveSessionError?> = LiveSessionBus.error

    val isScreenSharing: StateFlow<Boolean>
        get() = ScreenShareController.isSharing

    /** Last few turns, newest last, so a session can be summarised or logged. */
    private val transcript = ArrayDeque<Pair<String, String>>(24)
    private val transcriptLock = Any()

    fun recordTurn(user: String, assistant: String) {
        if (user.isBlank() && assistant.isBlank()) return
        synchronized(transcriptLock) {
            transcript.addLast(user to assistant)
            while (transcript.size > 24) transcript.removeFirst()
        }
    }

    fun transcriptSnapshot(): List<Pair<String, String>> =
        synchronized(transcriptLock) { transcript.toList() }

    // --- Starting and stopping ----------------------------------------------------------------

    /**
     * Starts a live conversation.
     *
     * Returns false, with the reason published to [liveError], when the microphone permission is
     * missing or when there is no way to answer: no provider key and no connected workspace.
     */
    fun startLive(context: Context, mode: LiveMode, hostLightMode: Boolean): Boolean {
        val app = context.applicationContext
        LiveSessionBus.setMode(mode)

        if (!LivePermissions.hasLiveConversationPermission(app)) {
            publish(
                LiveSessionError(
                    "MICROPHONE PERMISSION REQUIRED",
                    "Allow microphone access to start a live conversation.",
                    "MIC_PERMISSION_REQUIRED",
                    "ALLOW MICROPHONE"
                )
            )
            toast(app, "Live conversation needs the microphone.")
            return false
        }

        val config = currentApi()
        if (!config.hasKey && !hasHostLiveAgent()) {
            publish(
                LiveSessionError(
                    "AI CONNECTION REQUIRED",
                    "Connect your SAIF AI workspace, or add a provider API key under AI PROVIDER & MODELS in Settings.",
                    "API_KEY_MISSING",
                    "OPEN SETTINGS"
                )
            )
            toast(app, "Live conversation needs an AI provider key or a connected workspace.")
            return false
        }

        LiveSessionBus.setError(null)
        return try {
            val intent = android.content.Intent(app, LiveConversationService::class.java)
                .setAction(LiveConversationService.ACTION_START)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                app.startForegroundService(intent)
            } else {
                app.startService(intent)
            }
            true
        } catch (e: Throwable) {
            Log.w(TAG, "Could not start the conversation service", e)
            publish(
                LiveSessionError(
                    "LIVE SESSION COULD NOT START",
                    "The microphone service could not be started: ${e.localizedMessage ?: e.javaClass.simpleName}",
                    "LIVE_START_FAILED"
                )
            )
            false
        }
    }

    /** Ends the conversation, screen sharing included. */
    fun stopLive(context: Context) {
        runCatching { stopScreenShare() }
        val app = context.applicationContext
        runCatching {
            app.startService(
                android.content.Intent(app, LiveConversationService::class.java)
                    .setAction(LiveConversationService.ACTION_STOP)
            )
        }
        LiveSessionBus.setSessionOn(false)
    }

    fun setMicMuted(muted: Boolean) = runCatching { LiveConversationService.activeInstance()?.setMicMuted(muted) }

    fun interrupt() = runCatching { LiveConversationService.activeInstance()?.interrupt() }

    fun sendText(text: String) = runCatching { LiveConversationService.activeInstance()?.sendText(text) }

    fun clearLiveError() = LiveSessionBus.setError(null)

    /** Switches an already-running session between voice-only and screen sharing. */
    fun setMode(mode: LiveMode) = LiveSessionBus.setMode(mode)

    // --- Screen sharing -----------------------------------------------------------------------

    /**
     * Begins sending screen frames into the conversation.
     *
     * The service has to widen its foreground type first: Android 14 will not hand back a usable
     * projection to a service that did not declare media projection when it came to the foreground.
     */
    fun startScreenShare(projection: MediaProjection, metrics: DisplayMetrics): Boolean {
        if (!LiveConversationService.elevateToMediaProjection()) return false
        val started = try {
            ScreenShareController.start(projection, metrics) {
                // The user revoked capture from the system dialog: drop back to voice only.
                LiveSessionBus.setMode(LiveMode.NORMAL)
                LiveConversationService.demoteFromMediaProjection()
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Could not start screen capture", e)
            false
        }
        if (!started) {
            LiveConversationService.demoteFromMediaProjection()
            return false
        }
        LiveSessionBus.setScreenSharing(true)
        return true
    }

    fun stopScreenShare() {
        runCatching { ScreenShareController.stop() }
        LiveSessionBus.setScreenSharing(false)
        LiveConversationService.demoteFromMediaProjection()
    }

    /**
     * Why screen sharing is not delivering frames, or an empty string when it is healthy.
     *
     * Checked a few seconds after capture starts: a capture that will never work does not fail, it
     * just stays silent, so silence is the only symptom to look for.
     */
    val lastScreenShareError: String
        get() = ScreenShareController.lastError()

    fun wantsScreenShare(): Boolean = LiveSessionBus.mode.value == LiveMode.SCREEN_SHARE

    // --- Prompts ------------------------------------------------------------------------------

    /**
     * The system prompt handed to a newly created turn loop.
     *
     * Recall is pulled from SAIF AI's own memory rather than maintained here, so what the live
     * conversation knows and what typed chat knows are the same thing.
     */
    fun buildSystemPrompt(): String {
        val memory = hostMemory("live").trim()
        val autoLanguage = hostAutoLanguage()
        return buildString {
            append("You are SAIF AI, speaking out loud in a hands-free conversation on a phone. ")
            append("Answer in short spoken sentences, the way a person would, with no markdown, ")
            append("no bullet points and no code fences. ")
            append(if (autoLanguage) "Reply in the same language the user just spoke. " else "Reply in the user's chosen language. ")
            append("Never claim to have performed an action on the device unless it actually happened. ")
            append("Never claim to see the screen unless an image or a screen description is provided. ")
            if (memory.isNotEmpty()) {
                appendLine()
                append("What you remember about this user:")
                appendLine()
                append(memory)
            }
        }
    }

    // --- Internals ----------------------------------------------------------------------------

    private fun publish(error: LiveSessionError) = LiveSessionBus.setError(error)

    private fun toast(context: Context, message: String) {
        runCatching { Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
    }
}
