/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import java.util.UUID

/**
 * The conversation data model SAIF AI's own agent screens work with.
 *
 * Written from scratch. The fields are the ones the UI actually renders: a message carries its text,
 * an optional "thinking" passage, the tool calls made while producing it, and enough bookkeeping
 * (ids, timestamps, token usage) to render a feed without re-deriving anything.
 */

enum class MessageRole { USER, ASSISTANT, TOOL, SYSTEM, SUMMARY }

/** Which built-in capability a tool call belongs to, so the UI can pick an icon and a label. */
enum class ToolType {
    BASH,
    VIEW_FILE,
    EDIT_FILE,
    LIST_DIR,
    GREP_SEARCH,
    FIND,
    SEARCH_WEB,
    READ_URL,
    GENERATE_IMAGE,
    MCP,
    ASK_CHOICE,
    MATH,
    SYSTEM_NOTIFICATION,
    UNKNOWN;

    companion object {
        /** Maps a tool name reported by a model onto the closest built-in capability. */
        fun of(toolName: String): ToolType {
            val n = toolName.lowercase()
            return when {
                n in setOf("bash", "shell", "run_command", "terminal", "exec") -> BASH
                n in setOf("read_file", "view_file", "read", "cat") -> VIEW_FILE
                n in setOf("write_file", "edit_file", "edit", "patch", "write") -> EDIT_FILE
                n in setOf("list_dir", "ls", "listdir") -> LIST_DIR
                n in setOf("grep_search", "search_text", "grep", "search") -> GREP_SEARCH
                n in setOf("find", "glob") -> FIND
                n in setOf("search_web", "web_search", "websearch") -> SEARCH_WEB
                n in setOf("read_url", "http_get", "fetch", "browse") -> READ_URL
                n.contains("image") || n.contains("draw") -> GENERATE_IMAGE
                n.startsWith("mcp") -> MCP
                n in setOf("ask_choice", "ask_question", "choice", "question") -> ASK_CHOICE
                n in setOf("math", "calculator", "calc") -> MATH
                n in setOf("make_dir", "delete_file", "mkdir", "delete") -> EDIT_FILE
                else -> UNKNOWN
            }
        }
    }
}

/** Lifecycle of one tool call. Kept as a string so persisted values survive a rename. */
object ToolStatus {
    const val RUNNING = "RUNNING"
    const val PENDING_APPROVAL = "PENDING_APPROVAL"
    const val AWAITING_CHOICE = "AWAITING_CHOICE"
    const val SUCCESS = "SUCCESS"
    const val FAILED = "FAILED"
    const val TERMINATED = "TERMINATED"

    fun isActive(status: String) = status == RUNNING || status == PENDING_APPROVAL || status == AWAITING_CHOICE
}

/** One choice offered to the user inside a tool call. */
data class ChoiceOption(
    val id: String = "",
    val text: String = "",
    val description: String = ""
)

/** One question in a multi-question prompt. */
data class ChoiceQuestion(
    val id: String = "",
    val question: String = "",
    val options: List<ChoiceOption> = emptyList(),
    val isMultiSelect: Boolean = false,
    val allowCustomText: Boolean = true
)

/** A set of questions the agent needs answered before it can continue. */
data class ChoiceQuestionnaire(
    val title: String = "Clarification & Options",
    val description: String? = null,
    val questions: List<ChoiceQuestion> = emptyList(),
    val allowCustomNote: Boolean = true
)

/** One tool call, from the moment it is requested to the moment it finishes. */
data class ToolCall(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "bash",
    val toolType: ToolType = ToolType.BASH,
    val command: String = "",
    val status: String = ToolStatus.RUNNING,
    val output: String = "",
    val exitCode: Int? = null,
    val durationMs: Long? = null,
    val stepIndex: Int? = null,
    val trajectoryId: String? = null,
    val interactionType: String? = null,
    val questionnaire: ChoiceQuestionnaire? = null
) {
    fun isActive() = ToolStatus.isActive(status)
}

/** Token accounting for one reply, as the provider reports it. */
data class TokenUsage(
    val promptTokens: Int = 0,
    val outputTokens: Int = 0,
    val cachedTokens: Int = 0,
    val totalTokens: Int = 0,
    val durationMs: Long = 0L
)

/** A file, image or recording attached to a message. */
data class ChatAttachment(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val path: String = "",
    val isImage: Boolean = false,
    val isAudio: Boolean = false,
    val localUri: String? = null,
    val size: Long = 0L,
    val url: String? = null,
    val durationSeconds: Int = 0,
    val mimeType: String? = null,
    val base64: String? = null
)

/** One message in a conversation. */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val conversationId: String = "",
    val role: MessageRole = MessageRole.USER,
    val content: String = "",
    val thoughtText: String? = null,
    val thoughtDurationMs: Long? = null,
    val toolCalls: List<ToolCall> = emptyList(),
    val isStreaming: Boolean = false,
    val tokenUsage: TokenUsage? = null,
    val rawPayload: String? = null,
    val rawContent: String? = null,
    val contextSummary: String? = null,
    val stepIndex: Int? = null,
    val attachments: List<ChatAttachment> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val modelId: String? = null
)

/** One saved conversation. */
data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New Chat",
    val modelId: String = "",
    val sessionId: String = UUID.randomUUID().toString(),
    val summary: String? = null,
    val customSystemPrompt: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isRunning: Boolean = false,
    val notFullyIdle: Boolean = false,
    val hasActivity: Boolean = false,
    val runStatus: String = "IDLE",
    val stepCount: Int = 0,
    val workspaceUri: String = "",
    val parentConversationId: String? = null,
    val subagentRole: String? = null
)

/** Which agent backend owns a conversation. */
enum class AgentKind { AGY, CLAUDE, SAIF }

/** A tool call waiting for the user to allow or refuse it. */
data class PendingToolApproval(
    val toolCall: ToolCall,
    val messageId: String
)

/** One entry in the slash-command list. */
data class SlashCommandItem(
    val name: String,
    val command: String,
    val description: String,
    val type: String = "skill",
    val pluginName: String? = null,
    val path: String = "",
    val argumentHint: String = ""
)

/** The user's answer to one question in a [ChoiceQuestionnaire]. */
data class AskQuestionResponseItemDto(
    val question: String = "",
    val options: List<AskQuestionOptionDto> = emptyList(),
    val selectedOptionIds: List<String>? = null,
    val isMultiSelect: Boolean? = null,
    val writeInResponse: String? = null,
    val skipped: Boolean? = null
)

/** One option as answered, so an answer can be replayed verbatim. */
data class AskQuestionOptionDto(
    val id: String = "",
    val text: String = ""
)
