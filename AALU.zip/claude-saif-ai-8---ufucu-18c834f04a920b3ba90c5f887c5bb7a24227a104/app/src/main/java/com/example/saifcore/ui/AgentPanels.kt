/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saifcore.AgentKind
import com.example.saifcore.AskQuestionResponseItemDto
import com.example.saifcore.ChatMessage
import com.example.saifcore.ChoiceQuestion
import com.example.saifcore.PendingToolApproval
import com.example.saifcore.ToolCall
import com.example.saifcore.ToolType
import kotlinx.coroutines.flow.StateFlow

/**
 * The panels that ask the user for something mid-run: permission to act, or an answer to a question.
 *
 * Written from scratch. Both panels follow the same rule — **the agent waits, it does not give up.**
 * A refusal and a "cancel" are handed back to the model as information, so the run continues and the
 * agent can pick a different route instead of dead-ending on the first thing the user said no to.
 */
private val Accent = Color(0xFF7C5CE0)
private val OnDark = Color(0xFFF4F3F0)
private val Muted = Color(0xFFA8A59B)
private val Warn = Color(0xFFF59E0B)

/** One option on an approval card. */
class ApprovalChoice(val label: String, val description: String, val onChoose: () -> Unit)

/** One request for permission. */
class ApprovalItem(
    val key: String,
    val agent: AgentKind,
    val icon: ImageVector,
    val title: String,
    val subtitle: String? = null,
    val target: String? = null,
    val preview: String? = null,
    val reason: String? = null,
    val choices: List<ApprovalChoice> = emptyList(),
    val onReject: (() -> Unit)? = null
)

/** A question the agent is waiting on, tied to the message that asked it. */
data class PendingQuestion(
    val agent: AgentKind,
    val toolCall: ToolCall,
    val messageId: String
)

/**
 * Turns pending approvals into cards.
 *
 * The three choices are the ones that matter in practice: allow once, allow for the rest of this run,
 * or refuse. Anything finer is a setting, not a prompt.
 */
fun agyApprovalItems(
    pending: List<PendingToolApproval>,
    onApprove: (toolCall: ToolCall, messageId: String, scope: String) -> Unit,
    onReject: (toolCall: ToolCall, messageId: String, reason: String?) -> Unit
): List<ApprovalItem> = pending.map { approval ->
    val call = approval.toolCall
    val (icon, title) = when (call.toolType) {
        ToolType.BASH -> Icons.Outlined.Terminal to "Run a command?"
        ToolType.EDIT_FILE -> Icons.Outlined.EditNote to "Edit a file?"
        ToolType.VIEW_FILE, ToolType.LIST_DIR, ToolType.FIND, ToolType.GREP_SEARCH ->
            Icons.Outlined.FolderOpen to "Read files?"
        ToolType.SEARCH_WEB -> Icons.Outlined.TravelExplore to "Search the web?"
        ToolType.READ_URL -> Icons.Outlined.Language to "Open a web page?"
        ToolType.GENERATE_IMAGE -> Icons.Outlined.Image to "Generate an image?"
        ToolType.MCP -> Icons.Outlined.Extension to "Use ${call.name.substringAfterLast("__")}?"
        else -> Icons.Outlined.Shield to "Allow ${call.name}?"
    }

    ApprovalItem(
        key = call.id,
        agent = AgentKind.SAIF,
        icon = icon,
        title = title,
        subtitle = call.name,
        preview = call.command.ifBlank { call.output }.takeIf { it.isNotBlank() },
        choices = listOf(
            ApprovalChoice("Allow", "Run this once.") {
                onApprove(call, approval.messageId, "ONCE")
            },
            ApprovalChoice("Allow for this run", "Do not ask again until the run ends.") {
                onApprove(call, approval.messageId, "RUN")
            }
        ),
        onReject = { onReject(call, approval.messageId, "Refused by the user.") }
    )
}

/** Finds the question the agent is waiting on, most recent first. */
fun findPendingQuestion(agent: AgentKind, messages: List<ChatMessage>): PendingQuestion? {
    for (message in messages.asReversed()) {
        val call = message.toolCalls.lastOrNull {
            it.toolType == ToolType.ASK_CHOICE &&
                it.status == "AWAITING_CHOICE" &&
                it.questionnaire?.questions?.isNotEmpty() == true
        }
        if (call != null) return PendingQuestion(agent, call, message.id)
    }
    return null
}

/** Convenience overload for callers holding the messages as a flow. */
fun findPendingQuestion(agent: AgentKind, messages: StateFlow<List<ChatMessage>>): PendingQuestion? =
    findPendingQuestion(agent, messages.value)

/**
 * One approval card at a time, with the whole batch dismissable at once.
 *
 * Batching the allow/deny matters: a run that asks for ten file writes should not cost ten taps when
 * the user has already decided they trust it.
 */
@Composable
fun AgentApprovalPanel(
    items: List<ApprovalItem>,
    modifier: Modifier = Modifier,
    onAllowAll: (() -> Unit)? = null,
    onDenyAll: (() -> Unit)? = null
) {
    val item = items.firstOrNull() ?: return

    Surface(
        modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, Warn.copy(alpha = 0.42f)),
        shadowElevation = 6.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(item.icon, contentDescription = null, tint = Warn, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.title, color = OnDark, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    item.subtitle?.let {
                        Text(it, color = Muted, fontSize = 11.5.sp, fontFamily = FontFamily.Monospace)
                    }
                }
                if (items.size > 1) {
                    Text("+${items.size - 1}", color = Muted, fontSize = 12.sp)
                }
            }

            item.target?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Accent, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }

            item.preview?.let { preview ->
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 160.dp)
                        .verticalScroll(rememberScrollState())
                        .background(Color(0xFF121110), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(preview, color = OnDark, fontSize = 12.sp, fontFamily = FontFamily.Monospace, lineHeight = 17.sp)
                }
            }

            item.reason?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = Muted, fontSize = 12.sp)
            }

            Spacer(Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item.choices.forEach { choice ->
                    OutlinedButton(onClick = choice.onChoose, modifier = Modifier.weight(1f)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(choice.label, fontSize = 12.5.sp)
                            Text(choice.description, fontSize = 10.sp, color = Muted)
                        }
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                item.onReject?.let { reject ->
                    TextButton(onClick = reject) { Text("Deny", color = Muted) }
                }
                if (items.size > 1) {
                    onAllowAll?.let { TextButton(onClick = it) { Text("Allow all", color = Accent) } }
                    onDenyAll?.let { TextButton(onClick = it) { Text("Deny all", color = Muted) } }
                }
            }
        }
    }
}

/**
 * One question at a time, with back / next, an "other" answer, and skip.
 *
 * Splitting a questionnaire into pages is deliberate: a wall of five questions gets skimmed and
 * mis-answered, whereas one question at a time gets read.
 */
@Composable
fun AgentQuestionPanel(
    question: PendingQuestion,
    modifier: Modifier = Modifier,
    onSubmit: (responses: List<AskQuestionResponseItemDto>, summary: String) -> Unit,
    onSkip: (responses: List<AskQuestionResponseItemDto>) -> Unit,
    onCancel: () -> Unit
) {
    val questions: List<ChoiceQuestion> = question.toolCall.questionnaire?.questions.orEmpty()
    if (questions.isEmpty()) return

    var page by remember(question.toolCall.id) { mutableIntStateOf(0) }
    // One slot per question, created inside remember so the list is not mutated during composition.
    val answers = remember(question.toolCall.id, questions.size) {
        mutableStateListOf<AskQuestionResponseItemDto>().apply {
            repeat(questions.size) { add(AskQuestionResponseItemDto()) }
        }
    }

    var note by remember(question.toolCall.id) { mutableStateOf("") }
    val current = questions.getOrNull(page) ?: return

    Surface(
        modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, Accent.copy(alpha = 0.42f)),
        shadowElevation = 6.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = question.toolCall.questionnaire?.title.orEmpty().ifBlank { "A quick question" },
                color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
            )
            question.toolCall.questionnaire?.description?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, color = Muted, fontSize = 12.sp)
            }

            Spacer(Modifier.height(10.dp))
            Text(current.question, color = OnDark, fontSize = 14.sp)

            Spacer(Modifier.height(10.dp))
            val selected = answers[page].selectedOptionIds.orEmpty()
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                current.options.forEach { option ->
                    val isChosen = option.id in selected
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isChosen) Accent.copy(alpha = 0.16f) else Color.Transparent,
                                RoundedCornerShape(10.dp)
                            )
                            .border(
                                1.dp,
                                if (isChosen) Accent else Color(0x33FFFFFF),
                                RoundedCornerShape(10.dp)
                            )
                            .clickable {
                                val next = if (current.isMultiSelect) {
                                    if (isChosen) selected - option.id else selected + option.id
                                } else listOf(option.id)
                                answers[page] = answers[page].copy(selectedOptionIds = next)
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(option.text, color = OnDark, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        if (isChosen) {
                            Box(modifier = Modifier.size(8.dp).background(Accent, RoundedCornerShape(4.dp)))
                        }
                    }
                }
            }

            if (current.allowCustomText) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = {
                        note = it
                        answers[page] = answers[page].copy(writeInResponse = it)
                    },
                    label = { Text("Other") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onCancel) { Text("Cancel", color = Muted) }
                Row {
                    if (page > 0) TextButton(onClick = { page-- }) { Text("Back", color = Muted) }
                    if (page < questions.lastIndex) {
                        TextButton(onClick = { page++ }) { Text("Next", color = Accent) }
                    } else {
                        TextButton(onClick = {
                            onSubmit(answers.toList(), note.trim())
                        }) { Text("Submit", color = Accent) }
                    }
                    TextButton(onClick = { onSkip(answers.toList()) }) { Text("Skip", color = Muted) }
                }
            }
        }
    }
}
