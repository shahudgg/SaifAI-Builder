/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Startup and background jobs for SAIF AI's own engine.
 *
 * Written from scratch. Everything here is defensive on purpose: these run while the app is
 * starting, and a failure in an optional background job must never stop the app from opening.
 */

/**
 * Boots the engine once per process.
 *
 * Idempotent and cheap after the first call — startup paths call it from several places, and the
 * user should not pay for that more than once.
 */
object EngineBootstrap {

    @Volatile
    private var started = false

    fun ensureStarted(application: android.app.Application) {
        if (started) return
        synchronized(this) {
            if (started) return
            started = true
        }

        com.example.saifagent.SaifAgent.init(application)
        AuthPreferences.rememberEndpoints(
            AuthPreferences(application).bridgeHttpUrl,
            AuthPreferences(application).hubUrl
        )
        AntigravityAppBinding.init(application)

        runCatching { AndroidLocalBridgeServer.instance.start(application) }
        runCatching { SlashCommandsCache.getCommands() }
        runCatching { CustomSlashCommands.init(application) }
    }
}

/**
 * Periodically checks whether the bundled tool plugins have updates.
 *
 * A daily check with a network constraint is the polite version of this job: it costs almost nothing,
 * and it only runs when the device is already online.
 */
class PluginUpdateCheckWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {

    /**
     * Compares the recorded plugin version with the one in the assets and records the result.
     *
     * There is no download here on purpose — telling the user an update exists is useful; silently
     * replacing code on their device is not.
     */
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
        val recorded = prefs.getString("plugin_version_recorded", "").orEmpty()
        val bundled = runCatching {
            applicationContext.assets.list("plugins").orEmpty().size.toString()
        }.getOrDefault("")
        if (bundled.isNotBlank() && bundled != recorded) {
            prefs.edit()
                .putString("plugin_version_recorded", bundled)
                .putBoolean("plugin_update_available", recorded.isNotBlank())
                .apply()
        }
        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "saif_plugin_update_check"

        fun schedule(context: Context) {
            runCatching {
                val request = PeriodicWorkRequestBuilder<PluginUpdateCheckWorker>(1, TimeUnit.DAYS)
                    .setConstraints(
                        Constraints.Builder()
                            .setRequiredNetworkType(NetworkType.CONNECTED)
                            .build()
                    )
                    .build()
                WorkManager.getInstance(context.applicationContext)
                    .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
            }
        }
    }
}

/**
 * Which agent backends the user has switched on.
 *
 * Stored as a set of names so a future backend can be added without a migration, and read
 * synchronously because the chat screen asks before it renders.
 */
class AgentPreferences(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val _enabled = kotlinx.coroutines.flow.MutableStateFlow(enabledSync(context))
    val enabled: kotlinx.coroutines.flow.StateFlow<Set<AgentKind>> = _enabled

    private val _hasChosen = kotlinx.coroutines.flow.MutableStateFlow(hasChosenSync(context))
    val hasChosen: kotlinx.coroutines.flow.StateFlow<Boolean> = _hasChosen

    fun setEnabled(agents: Set<AgentKind>) {
        prefs.edit().putStringSet(KEY_ENABLED, agents.map { it.name }.toSet()).apply()
        prefs.edit().putBoolean(KEY_CHOSEN, true).apply()
        _enabled.value = agents
        _hasChosen.value = true
    }

    companion object {
        private const val PREFS = "saif_agent_choice"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_CHOSEN = "chosen"

        fun hasChosenSync(context: Context): Boolean =
            context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_CHOSEN, false)

        fun enabledSync(context: Context): Set<AgentKind> {
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val names = prefs.getStringSet(KEY_ENABLED, null)
            if (names.isNullOrEmpty()) return setOf(AgentKind.SAIF)
            return names.mapNotNull { runCatching { AgentKind.valueOf(it) }.getOrNull() }.toSet()
                .ifEmpty { setOf(AgentKind.SAIF) }
        }

        /** Command-line flags describing the enabled backends, for tools that ask for them. */
        fun bridgeFlags(context: Context): String {
            val enabled = enabledSync(context)
            if (enabled.isEmpty()) return ""
            return enabled.joinToString(" ") { "--agent=${it.name.lowercase()}" }
        }
    }
}
