/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.edit

/**
 * SAIF AI's runtime preferences.
 *
 * Written from scratch on plain [SharedPreferences]: these values are read while a reply is
 * streaming and while the terminal is starting, so they must be readable synchronously from any
 * thread without waiting on a coroutine or a DataStore initialisation. Every read has a default, so
 * a missing key is never an error.
 *
 * The class is intentionally a thin typed wrapper rather than a repository: the settings screen
 * writes, the engine reads, and nothing in between transforms the values.
 */
class AuthPreferences(private val context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---- Local server endpoints -------------------------------------------------------------

    var bridgeHttpUrl: String
        get() = prefs.getString(KEY_BRIDGE_HTTP_URL, DEFAULT_BRIDGE_HTTP_URL) ?: DEFAULT_BRIDGE_HTTP_URL
        set(value) = prefs.edit { putString(KEY_BRIDGE_HTTP_URL, value.trim()) }

    var hubUrl: String
        get() = prefs.getString(KEY_HUB_URL, DEFAULT_HUB_URL) ?: DEFAULT_HUB_URL
        set(value) = prefs.edit { putString(KEY_HUB_URL, value.trim()) }

    /**
     * Where the Linux userland comes from.
     *
     * SAIF AI ships proot itself, but a whole distribution is far too large to bundle, so it is
     * fetched once and cached. The default is a glibc Debian rootfs, because the provider CLIs
     * people actually want to run (OpenCode, Claude Code, Codex) are Node.js programs and will not
     * start against musl. Left editable because a person may prefer a different distribution, a
     * newer version, or a mirror of their own.
     */
    var linuxPackageUrl: String
        get() = prefs.getString(KEY_LINUX_PACKAGE_URL, DEFAULT_LINUX_PACKAGE_URL) ?: DEFAULT_LINUX_PACKAGE_URL
        set(value) = prefs.edit { putString(KEY_LINUX_PACKAGE_URL, value.trim()) }

    // ---- Tool switches ----------------------------------------------------------------------

    var isTerminalToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_TERMINAL_TOOL, true)
        set(value) = prefs.edit { putBoolean(KEY_TERMINAL_TOOL, value) }

    var autoExecuteTerminal: Boolean
        get() = prefs.getBoolean(KEY_AUTO_EXECUTE_TERMINAL, false)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_EXECUTE_TERMINAL, value) }

    var isWebSearchToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_WEB_SEARCH_TOOL, true)
        set(value) = prefs.edit { putBoolean(KEY_WEB_SEARCH_TOOL, value) }

    var isWebReaderToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_WEB_READER_TOOL, true)
        set(value) = prefs.edit { putBoolean(KEY_WEB_READER_TOOL, value) }

    var isChoicesToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_CHOICES_TOOL, true)
        set(value) = prefs.edit { putBoolean(KEY_CHOICES_TOOL, value) }

    var isFileToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_FILE_TOOL, true)
        set(value) = prefs.edit { putBoolean(KEY_FILE_TOOL, value) }

    var isAutomationToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTOMATION_TOOL, true)
        set(value) = prefs.edit { putBoolean(KEY_AUTOMATION_TOOL, value) }

    var isMathToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_MATH_TOOL, true)
        set(value) = prefs.edit { putBoolean(KEY_MATH_TOOL, value) }

    var isInteractiveUiToolEnabled: Boolean
        get() = prefs.getBoolean(KEY_INTERACTIVE_UI_TOOL, false)
        set(value) = prefs.edit { putBoolean(KEY_INTERACTIVE_UI_TOOL, value) }

    // ---- Local Linux environment ------------------------------------------------------------

    var isLocalToolsEnabled: Boolean
        get() = prefs.getBoolean(KEY_LOCAL_TOOLS_ENABLED, true)
        set(value) = prefs.edit { putBoolean(KEY_LOCAL_TOOLS_ENABLED, value) }

    var isLocalToolsInstalled: Boolean
        get() = prefs.getBoolean(KEY_LOCAL_TOOLS_INSTALLED, false)
        set(value) = prefs.edit { putBoolean(KEY_LOCAL_TOOLS_INSTALLED, value) }

    var localToolsInstallDate: Long
        get() = prefs.getLong(KEY_LOCAL_TOOLS_INSTALL_DATE, 0L)
        set(value) = prefs.edit { putLong(KEY_LOCAL_TOOLS_INSTALL_DATE, value) }

    var localToolsVersion: String
        get() = prefs.getString(KEY_LOCAL_TOOLS_VERSION, "") ?: ""
        set(value) = prefs.edit { putString(KEY_LOCAL_TOOLS_VERSION, value) }

    // ---- Model choice -----------------------------------------------------------------------

    var preferredModelId: String
        get() = prefs.getString(KEY_PREFERRED_MODEL_ID, "") ?: ""
        set(value) = prefs.edit { putString(KEY_PREFERRED_MODEL_ID, value.trim()) }

    var contextWindowLimit: Int
        get() = prefs.getInt(KEY_CONTEXT_WINDOW_LIMIT, DEFAULT_CONTEXT_WINDOW)
        set(value) = prefs.edit { putInt(KEY_CONTEXT_WINDOW_LIMIT, value.coerceIn(2_000, 2_000_000)) }

    var devModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_DEV_MODE, false)
        set(value) = prefs.edit { putBoolean(KEY_DEV_MODE, value) }

    var workingAnimationEnabled: Boolean
        get() = prefs.getBoolean(KEY_WORKING_ANIMATION, true)
        set(value) = prefs.edit { putBoolean(KEY_WORKING_ANIMATION, value) }

    var chatDividersEnabled: Boolean
        get() = prefs.getBoolean(KEY_CHAT_DIVIDERS, true)
        set(value) = prefs.edit { putBoolean(KEY_CHAT_DIVIDERS, value) }

    var chatFontScale: Float
        get() = prefs.getFloat(KEY_CHAT_FONT_SCALE, 1f)
        set(value) = prefs.edit { putFloat(KEY_CHAT_FONT_SCALE, value.coerceIn(0.7f, 1.8f)) }

    var terminalFontSize: Int
        get() = prefs.getInt(KEY_TERMINAL_FONT_SIZE, 12)
        set(value) = prefs.edit { putInt(KEY_TERMINAL_FONT_SIZE, value.coerceIn(8, 28)) }

    var terminalCursorStyle: String
        get() = prefs.getString(KEY_TERMINAL_CURSOR_STYLE, "BLOCK") ?: "BLOCK"
        set(value) = prefs.edit { putString(KEY_TERMINAL_CURSOR_STYLE, value.trim()) }

    var useSshTerminal: Boolean
        get() = prefs.getBoolean(KEY_USE_SSH_TERMINAL, false)
        set(value) = prefs.edit { putBoolean(KEY_USE_SSH_TERMINAL, value) }

    // ---- Terminal launcher icon -------------------------------------------------------------

    var terminalLauncherEnabled: Boolean
        get() = prefs.getBoolean(KEY_TERMINAL_LAUNCHER_ENABLED, false)
        set(value) = prefs.edit { putBoolean(KEY_TERMINAL_LAUNCHER_ENABLED, value) }

    var terminalLauncherStyle: String
        get() = prefs.getString(KEY_TERMINAL_LAUNCHER_STYLE, TerminalLauncherManager.STYLE_TERMUX)
            ?: TerminalLauncherManager.STYLE_TERMUX
        set(value) = prefs.edit { putString(KEY_TERMINAL_LAUNCHER_STYLE, value.trim()) }

    var hasSeenTerminalLauncherOnboarding: Boolean
        get() = prefs.getBoolean(KEY_TERMINAL_LAUNCHER_ONBOARDING, false)
        set(value) = prefs.edit { putBoolean(KEY_TERMINAL_LAUNCHER_ONBOARDING, value) }

    /** Whether the agent may run commands without asking first. */
    fun commandPolicy(): String =
        if (autoExecuteTerminal) "CASCADE_COMMANDS_AUTO_EXECUTION_EAGER"
        else "CASCADE_COMMANDS_AUTO_EXECUTION_OFF"

    companion object {
        const val PREFS = "saif_core_prefs"

        const val DEFAULT_BRIDGE_HTTP_URL = "http://127.0.0.1:1234"
        const val DEFAULT_HUB_URL = "http://127.0.0.1:1235"
        const val DEFAULT_CONTEXT_WINDOW = 120_000

        /** debian-trixie aarch64 from termux/proot-distro: glibc, so Node.js CLIs work. */
        const val DEFAULT_LINUX_PACKAGE_URL =
            "https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-aarch64-pd-v4.29.0.tar.xz"

        internal const val KEY_BRIDGE_HTTP_URL = "bridge_http_url"
        internal const val KEY_HUB_URL = "hub_url"
        internal const val KEY_LINUX_PACKAGE_URL = "linux_package_url"
        internal const val KEY_TERMINAL_TOOL = "terminal_tool"
        internal const val KEY_AUTO_EXECUTE_TERMINAL = "auto_execute_terminal"
        internal const val KEY_WEB_SEARCH_TOOL = "web_search_tool"
        internal const val KEY_WEB_READER_TOOL = "web_reader_tool"
        internal const val KEY_CHOICES_TOOL = "choices_tool"
        internal const val KEY_FILE_TOOL = "file_tool"
        internal const val KEY_AUTOMATION_TOOL = "automation_tool"
        internal const val KEY_MATH_TOOL = "math_tool"
        internal const val KEY_INTERACTIVE_UI_TOOL = "interactive_ui_tool"
        internal const val KEY_LOCAL_TOOLS_ENABLED = "local_tools_enabled"
        internal const val KEY_LOCAL_TOOLS_INSTALLED = "local_tools_installed"
        internal const val KEY_LOCAL_TOOLS_INSTALL_DATE = "local_tools_install_date"
        internal const val KEY_LOCAL_TOOLS_VERSION = "local_tools_version"
        internal const val KEY_PREFERRED_MODEL_ID = "preferred_model_id"
        internal const val KEY_CONTEXT_WINDOW_LIMIT = "context_window_limit"
        internal const val KEY_DEV_MODE = "dev_mode"
        internal const val KEY_WORKING_ANIMATION = "working_animation"
        internal const val KEY_CHAT_DIVIDERS = "chat_dividers"
        internal const val KEY_CHAT_FONT_SCALE = "chat_font_scale"
        internal const val KEY_TERMINAL_FONT_SIZE = "terminal_font_size"
        internal const val KEY_TERMINAL_CURSOR_STYLE = "terminal_cursor_style"
        internal const val KEY_USE_SSH_TERMINAL = "use_ssh_terminal"
        internal const val KEY_TERMINAL_LAUNCHER_ENABLED = "terminal_launcher_enabled"
        internal const val KEY_TERMINAL_LAUNCHER_STYLE = "terminal_launcher_style"
        internal const val KEY_TERMINAL_LAUNCHER_ONBOARDING = "terminal_launcher_onboarding"

        /**
         * Endpoints that were only ever placeholders.
         *
         * The bridge and hub used to be services the app expected to find already running, and
         * these were the addresses it guessed. Nothing ever listened there, which is why signing
         * in appeared to do nothing. The app now starts its own workspace daemon, so when the
         * stored value is still one of these guesses and a daemon is running, the daemon wins.
         *
         * Anything else is an address a person typed, and that is always respected.
         */
        private val PLACEHOLDER_ENDPOINTS = setOf(
            DEFAULT_BRIDGE_HTTP_URL,
            DEFAULT_HUB_URL,
            "http://127.0.0.1:1236",
            "http://127.0.0.1:1237"
        )

        private fun isPlaceholder(url: String): Boolean =
            url.trim().trimEnd('/') in PLACEHOLDER_ENDPOINTS

        /** The bridge endpoint last configured, read without constructing the class. */
        val currentBridgeHttpUrl: String
            get() {
                val configured = lastConfiguredBridgeUrl
                val daemon = daemonBaseUrl
                return if (daemon.isNotBlank() && isPlaceholder(configured)) daemon else configured
            }

        /** The hub endpoint last configured, read without constructing the class. */
        val currentHubUrl: String
            get() {
                val configured = lastConfiguredHubUrl
                val daemon = daemonBaseUrl
                return if (daemon.isNotBlank() && isPlaceholder(configured)) daemon else configured
            }

        @Volatile
        private var lastConfiguredBridgeUrl: String = DEFAULT_BRIDGE_HTTP_URL

        @Volatile
        private var lastConfiguredHubUrl: String = DEFAULT_HUB_URL

        /**
         * Where the workspace daemon this app started is listening, or blank when it is not
         * running. Set by [com.example.saifcore.SaifDaemon] once the daemon answers.
         */
        @Volatile
        var daemonBaseUrl: String = ""
            internal set

        internal fun rememberEndpoints(bridge: String, hub: String) {
            if (bridge.isNotBlank()) lastConfiguredBridgeUrl = bridge
            if (hub.isNotBlank()) lastConfiguredHubUrl = hub
        }
    }
}

/**
 * Keeps the way into SAIF AI open.
 *
 * The app used to ship alternative launcher icons for its terminal, switched by enabling and
 * disabling manifest aliases. The terminal is now reached from inside the app, so those aliases
 * are gone and there is nothing to switch between. What is left is the part that actually
 * mattered: making sure the main activity's component is enabled, so a build that once disabled
 * it can never leave the user with an app that has no launcher entry at all.
 *
 * The style constants are kept because a value may already be stored for them.
 *
 * Failure is swallowed on purpose - if the launcher refuses the change the app is still usable,
 * and a crash here would be far worse than a setting that silently does not stick.
 */
object TerminalLauncherManager {

    const val STYLE_ANTITERM = "ANTITERM"
    const val STYLE_TERMUX = "TERMUX"

    private fun mainActivityComponent(context: Context): ComponentName =
        ComponentName(context.packageName, "$PKG.MainActivity")

    private const val PKG = "com.example.saifai"
    private const val KEY_ENABLED = "terminal_launcher_enabled"
    private const val KEY_STYLE = "terminal_launcher_style"

    fun isLauncherEnabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)

    fun getLauncherStyle(context: Context): String =
        context.applicationContext.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
            .getString(KEY_STYLE, STYLE_TERMUX) ?: STYLE_TERMUX

    /**
     * Applies the launcher setting. The only effect now is guaranteeing that SAIF AI's own
     * activity stays enabled; [enabled] and [style] are accepted so existing call sites and any
     * stored value keep working unchanged.
     */
    fun applyLauncherSetting(context: Context, enabled: Boolean, style: String) {
        val pm = context.applicationContext.packageManager
        setComponentSafe(pm, mainActivityComponent(context), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
    }

    private fun setComponentSafe(pm: PackageManager, component: ComponentName, state: Int) {
        runCatching {
            val current = pm.getComponentEnabledSetting(component)
            if (current != PackageManager.COMPONENT_ENABLED_STATE_DEFAULT || state != PackageManager.COMPONENT_ENABLED_STATE_DEFAULT) {
                pm.setComponentEnabledSetting(component, state, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
