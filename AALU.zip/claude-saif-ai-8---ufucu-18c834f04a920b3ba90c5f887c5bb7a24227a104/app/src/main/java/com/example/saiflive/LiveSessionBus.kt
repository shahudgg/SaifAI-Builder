/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The one place a live session's state lives.
 *
 * It is a process-wide object rather than fields on the service because the service is restarted
 * mid-session: elevating to a media-projection foreground service on Android 14 means stopping and
 * starting it again, and the UI would otherwise see the session blink out of existence while the
 * user is still talking.
 *
 * Only the session host writes to it. The UI reads it and never mutates it.
 */
internal object LiveSessionBus {

    private val _isSessionOn = MutableStateFlow(false)
    val isSessionOn: StateFlow<Boolean> = _isSessionOn.asStateFlow()

    private val _state = MutableStateFlow(LiveConversationState.IDLE)
    val state: StateFlow<LiveConversationState> = _state.asStateFlow()

    private val _mode = MutableStateFlow(LiveMode.NORMAL)
    val mode: StateFlow<LiveMode> = _mode.asStateFlow()

    private val _userTranscript = MutableStateFlow("")
    val userTranscript: StateFlow<String> = _userTranscript.asStateFlow()

    private val _assistantTranscript = MutableStateFlow("")
    val assistantTranscript: StateFlow<String> = _assistantTranscript.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

    private val _isScreenSharing = MutableStateFlow(false)
    val isScreenSharing: StateFlow<Boolean> = _isScreenSharing.asStateFlow()

    private val _error = MutableStateFlow<LiveSessionError?>(null)
    val error: StateFlow<LiveSessionError?> = _error.asStateFlow()

    /** True while the service object exists, which is not the same as [isSessionOn]. */
    private val _isServiceAlive = MutableStateFlow(false)
    val isServiceAlive: StateFlow<Boolean> = _isServiceAlive.asStateFlow()

    fun setSessionOn(on: Boolean) {
        _isSessionOn.value = on
        if (!on) {
            _state.value = LiveConversationState.IDLE
            _audioLevel.value = 0f
            _userTranscript.value = ""
            _assistantTranscript.value = ""
            _isScreenSharing.value = false
        }
    }

    fun setState(state: LiveConversationState) {
        _state.value = state
    }

    fun setMode(mode: LiveMode) {
        _mode.value = mode
    }

    fun setUserTranscript(text: String) {
        _userTranscript.value = text
    }

    fun setAssistantTranscript(text: String) {
        _assistantTranscript.value = text
    }

    fun setAudioLevel(level: Float) {
        _audioLevel.value = level.coerceIn(0f, 1f)
    }

    fun setScreenSharing(sharing: Boolean) {
        _isScreenSharing.value = sharing
    }

    fun setError(error: LiveSessionError?) {
        _error.value = error
    }

    fun setServiceAlive(alive: Boolean) {
        _isServiceAlive.value = alive
    }
}
