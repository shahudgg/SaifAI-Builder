/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.vosk.Model
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/**
 * Speech recognition that runs entirely on the phone.
 *
 * It exists because most providers sell transcription separately from chat: a user whose key works
 * perfectly for conversation can still have no way to speak to SAIF AI. Recognising on-device means
 * live conversation works with any key at all, and it means nothing the user says leaves the phone
 * unless a reply already requires it.
 *
 * The engine underneath is Vosk (Apache 2.0). This is SAIF AI's own wrapper around it; the model is
 * fetched on first use rather than bundled, so the APK stays a sane size and the model can be
 * updated without shipping a new build.
 */
object OfflineSpeechEngine {

    private const val TAG = "OfflineSpeechEngine"

    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val MODEL_DIR = "offline-speech-model"

    /** Present in a completed Vosk model; used to decide whether a download is still needed. */
    private const val MODEL_MARKER = "am/final.mdl"

    private const val SAMPLE_RATE = 16000.0f

    /** Chunk size accepted by the recogniser. 4096 bytes is 128 ms of 16 kHz 16-bit audio. */
    private const val CHUNK = 4096

    private val isInitialising = AtomicBoolean(false)

    @Volatile
    private var model: Model? = null

    private val _isModelReady = MutableStateFlow(false)
    val isModelReady: StateFlow<Boolean> = _isModelReady.asStateFlow()

    @Volatile
    private var lastFailure: String? = null

    /** Why the model is not available, for the UI to explain instead of silently doing nothing. */
    fun lastFailure(): String? = lastFailure

    /**
     * Loads the model, downloading it first if this device has never had it.
     *
     * Safe to call repeatedly and from several places: only the first call does any work, and
     * callers that need the model wait on [isModelReady] rather than on this function.
     */
    fun init(context: Context, scope: CoroutineScope) {
        if (_isModelReady.value || !isInitialising.compareAndSet(false, true)) return
        scope.launch(Dispatchers.IO) {
            try {
                val directory = File(context.applicationContext.filesDir, MODEL_DIR)
                if (!File(directory, MODEL_MARKER).exists()) {
                    Log.i(TAG, "Fetching the on-device speech model")
                    downloadAndUnpack(MODEL_URL, directory)
                }
                val loaded = Model(directory.absolutePath)
                model = loaded
                lastFailure = null
                _isModelReady.value = true
                Log.i(TAG, "The on-device speech model is ready")
            } catch (e: Throwable) {
                lastFailure = e.message ?: e.javaClass.simpleName
                Log.w(TAG, "Could not prepare the on-device speech model", e)
            } finally {
                isInitialising.set(false)
            }
        }
    }

    /**
     * Transcribes one already-captured turn.
     *
     * Takes raw PCM rather than owning the microphone, because the live pipeline already holds the
     * capture and handing it over mid-session would drop the barge-in path.
     *
     * Returns null when the model is not loaded yet, which the caller treats as "try the network
     * instead" rather than as an empty answer.
     */
    fun transcribePcm(pcm: ByteArray): String? {
        val loaded = model ?: return null
        if (pcm.isEmpty()) return null
        val recognizer = try {
            org.vosk.Recognizer(loaded, SAMPLE_RATE)
        } catch (e: Throwable) {
            Log.w(TAG, "Could not open a recogniser", e)
            return null
        }
        return try {
            val parts = mutableListOf<String>()
            var offset = 0
            while (offset < pcm.size) {
                val length = minOf(CHUNK, pcm.size - offset)
                val chunk = pcm.copyOfRange(offset, offset + length)
                if (recognizer.acceptWaveForm(chunk, length)) {
                    textOf(recognizer.result)?.let { parts.add(it) }
                }
                offset += length
            }
            textOf(recognizer.finalResult)?.let { parts.add(it) }
            parts.joinToString(" ").trim().takeIf { it.isNotBlank() }
        } catch (e: Throwable) {
            Log.w(TAG, "On-device transcription failed", e)
            null
        } finally {
            runCatching { recognizer.close() }
        }
    }

    private fun textOf(json: String?): String? {
        if (json.isNullOrBlank()) return null
        return runCatching { JSONObject(json).optString("text").trim().takeIf { it.isNotEmpty() } }
            .getOrNull()
    }

    /**
     * Downloads a zipped model and unpacks it into [targetDir].
     *
     * Entries are validated against the target directory before being written. An archive that
     * escapes its destination - a `..` path, or an absolute one - is refused entry by entry; the
     * model is fetched over the network, and treating its contents as trusted would turn a download
     * into arbitrary file writes.
     */
    private fun downloadAndUnpack(url: String, targetDir: File) {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            instanceFollowRedirects = true
        }
        try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("the model server answered ${connection.responseCode}")
            }
            connection.inputStream.use { stream ->
                if (!targetDir.exists() && !targetDir.mkdirs()) {
                    throw IllegalStateException("could not create ${targetDir.path}")
                }
                val root = targetDir.canonicalPath + File.separator
                ZipInputStream(stream.buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name.substringAfter('/', entry.name)
                        if (name.isNotEmpty() && !entry.isDirectory) {
                            val outFile = File(targetDir, name)
                            if (!outFile.canonicalPath.startsWith(root)) {
                                throw SecurityException("the archive tried to write outside the model folder: ${entry.name}")
                            }
                            outFile.parentFile?.mkdirs()
                            FileOutputStream(outFile).use { out -> zip.copyTo(out) }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
