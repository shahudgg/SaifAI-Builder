/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

import android.annotation.TargetApi
import android.graphics.ImageFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Turns a screen-capture grant into a stream of JPEG frames.
 *
 * A process-wide object rather than part of the service, for the same reason the session state is:
 * the service is stopped and started again when it elevates to a media-projection foreground
 * service, and dropping the virtual display on the way would end screen sharing exactly when the
 * user has just granted it.
 *
 * Frames are delivered on a dedicated background thread. Only the most recent frame ever matters,
 * so a frame that arrives while the consumer is still busy is dropped rather than queued; a backlog
 * of stale screenshots is worse than a missed one.
 */
internal object ScreenShareController {

    private const val TAG = "ScreenShareController"

    /** Screen frames are downscaled before encoding: full resolution is far more detail than a model needs. */
    private const val MAX_EDGE = 720

    private val lock = Any()

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var callbackThread: HandlerThread? = null
    private var callbackHandler: Handler? = null
    private var consumer: ((jpeg: ByteArray) -> Unit)? = null

    @Volatile
    private var encoding = false

    /** Frames delivered since the current capture began. */
    private val framesDelivered = AtomicLong(0)

    /** When the current capture began, for the health check below. */
    private val startedAtMs = AtomicLong(0L)

    /**
     * How long capture is given to produce its first frame before it is reported as unhealthy.
     *
     * A projection that will never deliver does not fail - it simply stays silent - so silence after
     * a few seconds is the only signal there is.
     */
    private const val FIRST_FRAME_GRACE_MS = 5_000L

    private val _isSharing = MutableStateFlow(false)
    val isSharing: StateFlow<Boolean> = _isSharing.asStateFlow()

    /** Attaches the frame consumer. A previous consumer is replaced. */
    fun setFrameConsumer(consumer: ((jpeg: ByteArray) -> Unit)?) {
        synchronized(lock) { this.consumer = consumer }
    }

    /**
     * Begins capturing the screen.
     *
     * [metrics] is the real display metrics the caller measured; the virtual display is created at
     * that size and then downscaled, because a mismatch here shows up as a stretched or cropped
     * screenshot on devices with a non-standard density.
     */
    fun start(
        projection: MediaProjection,
        metrics: DisplayMetrics,
        onStopped: () -> Unit = {}
    ): Boolean {
        stop()
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val scale = (MAX_EDGE.toFloat() / maxOf(width, height).toFloat()).coerceAtMost(1f)
        val captureWidth = (width * scale).toInt().coerceAtLeast(1)
        val captureHeight = (height * scale).toInt().coerceAtLeast(1)

        val thread = HandlerThread("saif-screen-capture").apply { start() }
        val handler = Handler(thread.looper)
        callbackThread = thread
        callbackHandler = handler

        val imageReader = try {
            ImageReader.newInstance(captureWidth, captureHeight, ImageFormat.JPEG, 2)
        } catch (e: Throwable) {
            Log.w(TAG, "Could not create the image reader", e)
            thread.quitSafely()
            callbackThread = null
            callbackHandler = null
            return false
        }
        reader = imageReader

        imageReader.setOnImageAvailableListener({ r ->
            if (!encoding) {
                encoding = true
                try {
                    val image = r.acquireLatestImage()
                    if (image != null) {
                        val bytes = image.toJpegBytes()
                        image.close()
                        if (bytes != null && bytes.isNotEmpty()) {
                            framesDelivered.incrementAndGet()
                            val sink = synchronized(lock) { consumer }
                            sink?.invoke(bytes)
                        }
                    }
                } catch (_: Throwable) {
                    // A dropped frame is not worth tearing the session down for.
                } finally {
                    encoding = false
                }
            }
        }, handler)

        val virtualDisplay = try {
            projection.createVirtualDisplay(
                "saif-screen-share",
                captureWidth,
                captureHeight,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                handler
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Could not create the virtual display", e)
            imageReader.close()
            reader = null
            thread.quitSafely()
            callbackThread = null
            callbackHandler = null
            return false
        }
        display = virtualDisplay

        this.projection = projection
        registerStopCallback(projection, onStopped)
        framesDelivered.set(0)
        startedAtMs.set(System.currentTimeMillis())
        _isSharing.value = true
        return true
    }

    fun stop() {
        synchronized(lock) { consumer = null }
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { callbackThread?.quitSafely() }
        display = null
        reader = null
        callbackThread = null
        callbackHandler = null
        encoding = false
        framesDelivered.set(0)
        startedAtMs.set(0L)
        val previous = projection
        projection = null
        if (previous != null) {
            runCatching { previous.stop() }
        }
        _isSharing.value = false
    }

    /**
     * Watches for the user revoking capture from the system cast dialog.
     *
     * Without this the session would keep reporting that it can see the screen long after Android
     * took the grant away, and SAIF AI would answer confidently about a screen it cannot see.
     */
    @TargetApi(21)
    private fun registerStopCallback(projection: MediaProjection, onStopped: () -> Unit) {
        val handler = callbackHandler ?: return
        runCatching {
            projection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post {
                        stop()
                        onStopped()
                    }
                }
            }, handler)
        }
    }

    /**
     * Why the current capture is not producing anything, or an empty string when it is healthy.
     *
     * The UI asks this once, several seconds after capture starts, because the failure it is looking
     * for has no callback: the projection is granted, the virtual display is created, and then not a
     * single frame ever arrives. Reporting "started" and then never seeing the screen would be worse
     * than saying so.
     */
    fun lastError(): String {
        if (!_isSharing.value) return ""
        if (framesDelivered.get() > 0) return ""
        val elapsed = System.currentTimeMillis() - startedAtMs.get()
        if (elapsed < FIRST_FRAME_GRACE_MS) return ""
        return "the system granted screen capture but has not delivered any frames"
    }

    /** Frames delivered so far, so callers can tell a slow start from a dead one. */
    fun framesDelivered(): Long = framesDelivered.get()

    /** Reads the single JPEG plane of a hardware buffer into a byte array. */
    private fun Image.toJpegBytes(): ByteArray? {
        if (format != ImageFormat.JPEG) return null
        val plane = planes.firstOrNull() ?: return null
        val buffer = plane.buffer ?: return null
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return bytes
    }
}
