/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/**
 * The one permission check a live conversation needs.
 *
 * Kept here rather than inlined at each call site because the answer is used in three different
 * places - starting the session, deciding whether the orb can offer a retry, and the permission
 * launcher's result handler - and they must never disagree about what "ready" means.
 */
object LivePermissions {

    /** True when the app currently holds everything a live conversation requires. */
    fun hasLiveConversationPermission(context: Context): Boolean =
        hasMicrophone(context) && canShowNotifications(context)

    fun hasMicrophone(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /**
     * Notifications are not optional for a foreground service: the running-session indicator is the
     * only thing telling the user the microphone is open. On Android 13 and above that needs a
     * granted permission, so a session started without it is a session the user cannot see.
     */
    fun canShowNotifications(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }
}
