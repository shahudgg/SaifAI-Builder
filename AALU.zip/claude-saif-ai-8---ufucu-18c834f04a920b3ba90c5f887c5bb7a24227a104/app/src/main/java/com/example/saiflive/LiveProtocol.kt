/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

/**
 * The vocabulary shared by SAIF AI's live-conversation feature.
 *
 * Everything here is deliberately small and one-directional: the session host (a foreground
 * service) publishes state, the UI reads it, and the artificial-intelligence half of a turn is
 * supplied by the host app through [HostLiveTurnLoop]. That split is what lets the microphone and
 * the service lifetime belong to the service while the thinking belongs to the app.
 */

/** Where a live conversation currently is. Drives the orb, the captions and the status pill. */
enum class LiveConversationState(val label: String) {
    /** Nothing is running. */
    IDLE("Idle"),

    /** The microphone is open and SAIF AI is waiting for speech. */
    LISTENING("Listening"),

    /** A request is in flight: transcribing, routing, or waiting on the provider. */
    THINKING("Thinking"),

    /** SAIF AI is speaking. The microphone stays open so the user can barge in. */
    SPEAKING("Speaking")
}

/** How much of the device a live session is allowed to see. */
enum class LiveMode(val label: String, val description: String) {
    /** Microphone only. */
    NORMAL("Voice", "Hands-free conversation with the microphone"),

    /** Microphone plus the screen, so SAIF AI can answer about what is on it. */
    SCREEN_SHARE("Screen", "Conversation that can also see your screen")
}

/**
 * A failure worth showing the user, with enough identity that the UI can offer the right way out.
 *
 * [errorCode] is what the UI switches on: `MIC_PERMISSION_REQUIRED` opens the permission request,
 * `API_KEY_MISSING` opens Settings, everything else offers a retry.
 */
data class LiveSessionError(
    val title: String,
    val message: String,
    val errorCode: String,
    val action: String = "RETRY"
)

/**
 * The provider settings SAIF AI's own Settings panel holds, as the live engine sees them.
 *
 * The engine never stores a key of its own; it reads whatever the user saved in Settings, so there
 * is exactly one place to change provider and exactly one key to revoke.
 */
data class LiveProviderConfig(
    val provider: String,
    val apiKey: String,
    val model: String
) {
    val hasKey: Boolean get() = apiKey.isNotBlank()
}

/** Outcome of comparing a recording against the enrolled owner's voice. */
data class SpeakerVerdict(
    /** True when the speaker is accepted. */
    val isMatch: Boolean,

    /** False when no usable voiceprint could be extracted, in which case [isMatch] means nothing. */
    val hasExtractedVector: Boolean,

    /** Cosine similarity in 0..1, for diagnostics and for tuning the threshold. */
    val score: Float
)

/**
 * The half of a live turn that thinks.
 *
 * SAIF AI supplies the implementation (see `com.example.live.LiveTurnLoop`); the session host owns
 * when it starts and stops. The host hands it raw microphone frames through the loop's own
 * pipeline - the loop opens the microphone itself, because echo cancellation has to be configured
 * with the same parameters the capture uses.
 */
interface HostLiveTurnLoop {
    /** Opens the capture pipeline. Returns false when the microphone could not be started. */
    fun start(): Boolean

    /** Stops the capture pipeline, cancels any in-flight turn and silences playback. */
    fun stop()

    /** Mutes capture without tearing the session down. */
    fun setMicMuted(muted: Boolean)

    /** Cuts off whatever SAIF AI is saying and returns to listening. */
    fun interrupt()

    /** Runs a turn from typed text instead of speech. */
    fun sendText(text: String)

    /** Latest screen frame as JPEG, or null when screen sharing is off. */
    fun onScreenFrame(jpeg: ByteArray?)
}

/** What the session host is told as a turn progresses. */
interface HostLiveTurnListener {
    fun onState(state: LiveConversationState)
    fun onUserTranscript(text: String)
    fun onAssistantTranscript(text: String)

    /** Microphone loudness, normalised 0..1, for the orb's reaction. */
    fun onAudioLevel(level: Float)

    /** Fired on detected speech. Used to keep the screen awake while someone is talking. */
    fun onActivity()

    fun onTurnCompleted(user: String, assistant: String)
    fun onError(error: LiveSessionError)
}
