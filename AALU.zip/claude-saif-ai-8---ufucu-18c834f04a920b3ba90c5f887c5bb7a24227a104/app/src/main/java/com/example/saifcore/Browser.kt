/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.edit
import java.io.File
import java.util.Locale

/**
 * The in-app browser's plugin host and tab manager.
 *
 * Written from scratch. The host is a small local HTTP server (reusing SAIF AI's own bridge rather
 * than adding a second one) that serves the bundled browser plugins; the tab manager only remembers
 * which URL each tab is on, because that is all the rest of the app needs from it.
 */
class BrowserExtensionManager private constructor() {

    /** A browser plugin bundled with the app. */
    data class Extension(
        val id: String,
        val name: String,
        val isEnabled: Boolean = true,
        val version: String = ""
    )

    @Volatile
    private var hostReady = false

    private var context: Context? = null

    fun init(context: Context) {
        this.context = context.applicationContext
    }

    /** Makes sure the plugin host is serving. Idempotent. */
    fun ensureHost() {
        val app = context ?: return
        if (hostReady) return
        AndroidLocalBridgeServer.instance.start(app)
        hostReady = true
    }

    /** The bundled plugins. Read from assets so a dropped file cannot masquerade as one. */
    fun loadExtensions(): List<Extension> {
        val app = context ?: return emptyList()
        val names = runCatching { app.assets.list("browser-extensions").orEmpty() }.getOrDefault(emptyArray())
        val disabled = disabledPluginIds(app)
        return names.sorted().map { id ->
            Extension(id = id, name = id.replace('-', ' ').replaceFirstChar { it.uppercase() }, isEnabled = id !in disabled)
        }
    }

    /** Verifies the host answers for a plugin. Throws with a usable message when it does not. */
    fun tools(extensionId: String) {
        ensureHost()
        val app = context ?: error("The browser host has not been started.")
        val port = AndroidLocalBridgeServer.instance.boundPort
        val url = "http://127.0.0.1:$port/ping"
        check(url.startsWith("http://127.0.0.1")) { "The plugin host is only reachable on this device." }
        check(loadExtensions().any { it.id == extensionId && it.isEnabled }) {
            "Plugin $extensionId is not installed or is disabled."
        }
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit { putLong("last_tools_check_$extensionId", System.currentTimeMillis()) }
    }

    /** The name a plugin's tools are registered under. */
    fun mcpServerName(extensionId: String): String = "saif_browser_${extensionId.lowercase(Locale.US).replace('-', '_')}"

    /** The URL a plugin's tool server listens on. */
    fun mcpUrl(extensionId: String): String =
        "http://127.0.0.1:${AndroidLocalBridgeServer.instance.boundPort}/mcp/${mcpServerName(extensionId)}"

    fun setEnabled(extensionId: String, enabled: Boolean) {
        val app = context ?: return
        val current = disabledPluginIds(app).toMutableSet()
        if (enabled) current.remove(extensionId) else current.add(extensionId)
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit {
            putStringSet(KEY_DISABLED, current)
        }
    }

    private fun disabledPluginIds(app: Context): Set<String> =
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_DISABLED, emptySet()).orEmpty()

    companion object {
        private const val PREFS = "saif_browser_plugins"
        private const val KEY_DISABLED = "disabled"

        val instance: BrowserExtensionManager by lazy { BrowserExtensionManager() }
    }
}

/**
 * Remembers the browser's tabs.
 *
 * Only the URL per tab is kept here — the WebView state belongs to the screen that owns it, and
 * duplicating it would only create two sources of truth that can disagree.
 */
class BrowserSessionManager private constructor() {

    @Volatile
    private var tabs: List<String> = emptyList()

    @Volatile
    private var activeIndex: Int = -1

    /** Opens [url], in a new tab when asked. */
    fun openUrl(url: String, newTab: Boolean = false) {
        if (url.isBlank()) return
        val next = if (newTab || tabs.isEmpty()) {
            tabs + url
        } else {
            tabs.toMutableList().also { it[activeIndex.coerceIn(0, tabs.lastIndex)] = url }
        }
        tabs = next
        activeIndex = if (newTab || activeIndex < 0) next.lastIndex else activeIndex.coerceIn(0, next.lastIndex)
    }

    fun tabs(): List<String> = tabs

    fun activeUrl(): String? = tabs.getOrNull(activeIndex)

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        tabs = tabs.filterIndexed { i, _ -> i != index }
        activeIndex = (activeIndex - 1).coerceAtLeast(if (tabs.isEmpty()) -1 else 0)
    }

    fun clear() {
        tabs = emptyList()
        activeIndex = -1
    }

    /** Opens a URL in the device browser, for links the in-app browser should not keep. */
    fun openExternal(context: Context, url: String) {
        val parsed = runCatching { Uri.parse(url) }.getOrNull() ?: return
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, parsed).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    companion object {
        val instance: BrowserSessionManager by lazy { BrowserSessionManager() }
    }
}

/**
 * Turns a stored profile picture value into something an image loader accepts.
 *
 * Handles the `data:image/…;base64,…` form as well as a plain URL, and returns null for a blank
 * value so callers can fall back to initials without a special case.
 */
fun parseProfileAvatarModel(profilePictureUrl: String?): Any? {
    if (profilePictureUrl.isNullOrBlank()) return null
    if (profilePictureUrl.startsWith("data:image/", ignoreCase = true)) {
        runCatching {
            val commaIndex = profilePictureUrl.indexOf(',')
            if (commaIndex > 0) {
                val base64 = profilePictureUrl.substring(commaIndex + 1).trim()
                return android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            }
        }
    }
    if (profilePictureUrl.startsWith("file://")) {
        val path = profilePictureUrl.removePrefix("file://")
        if (runCatching { File(path).isFile }.getOrDefault(false)) return File(path)
    }
    return profilePictureUrl
}

/**
 * A minimal ADB connection record.
 *
 * SAIF AI only needs to know whether wireless debugging is connected, so this tracks the one device
 * and refreshes on demand rather than maintaining a full pairing state machine.
 */
object AdbConnectManager {

    /** Whether a device is currently connected. */
    @Volatile
    var connected: Boolean = false
        private set

    @Volatile
    var lastError: String? = null
        private set

    fun init(context: Context) {
        // Nothing to restore: a wireless debugging connection never survives a process restart.
        connected = false
    }

    /**
     * Re-checks whether a wireless debugging device is reachable.
     *
     * Reads the ADB TCP port through the hidden system-property API by reflection, because there
     * is no public way to ask. Anything going wrong is reported as "not connected" rather than
     * thrown: this only gates an optional capability.
     */
    fun refresh() {
        lastError = null
        connected = false
        try {
            val clazz: Class<*> = Class.forName("android.os.SystemProperties")
            val getter: java.lang.reflect.Method = clazz.getDeclaredMethod("get", String::class.java)
            val raw: Any? = getter.invoke(null, "service.adb.tcp.port")
            val value: String = if (raw == null) "" else raw.toString()
            connected = value.isNotEmpty() && value != "-1"
        } catch (t: Throwable) {
            lastError = t.message
        }
    }
}
