/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Which full-screen surface the app is showing. */
enum class AppViewMode { CHAT, IDE, TERMINAL, BROWSER, NOTES }

/**
 * The engine ViewModel — the single object the UI watches to know how the agent is doing.
 *
 * Written from scratch. It deliberately holds no business logic of its own: it owns the backend and
 * the connection state, and forwards everything else. That keeps one place to look when the UI asks
 * "can I send this?" and one place to restart when something goes wrong.
 */
class SaifEngineViewModel(application: Application) : AndroidViewModel(application) {

    val authPreferences = AuthPreferences(application)

    private val store = ChatSessionStore()

    val agyBackend: SaifAgentBackend = SaifAgentBackend(
        application = application,
        backendScope = viewModelScope,
        authPrefs = authPreferences,
        store = store,
        isNetworkConnectedProvider = { isNetworkConnected() },
        onHubOnline = { agyBackend.refreshModelsAsync() },
        commandPolicyProvider = { authPreferences.commandPolicy() },
        authInfoProvider = { _agyAuthInfo.value }
    )

    // ---- Connection ----------------------------------------------------------------------------

    private val _systemConnectionState =
        MutableStateFlow<SystemConnectionState>(SystemConnectionState.Idle)
    val systemConnectionState: StateFlow<SystemConnectionState> = _systemConnectionState.asStateFlow()

    private val _isNetworkConnectedState = MutableStateFlow(isNetworkConnected())
    val isNetworkConnectedState: StateFlow<Boolean> = _isNetworkConnectedState.asStateFlow()

    private val _agyAuthInfo = MutableStateFlow(AgyHubClient.AgyAuthInfo())
    val agyAuthInfo: StateFlow<AgyHubClient.AgyAuthInfo> = _agyAuthInfo.asStateFlow()

    val isAuthBusy: StateFlow<Boolean> get() = agyBackend.isAuthBusy
    val authFeedbackMessage get() = agyBackend.authFeedbackMessage

    /** A sign-in the user has to finish in a browser. */
    val agyLoginIssue: StateFlow<SaifAgentBackend.AgyLoginIssue?> get() = agyBackend.agyLoginIssue

    /** The sign-in URL waiting to be opened, if any. */
    val pendingLoginUrl: StateFlow<String?> get() = agyBackend.pendingLoginUrl

    fun clearAgyLoginIssue() = agyBackend.clearAgyLoginIssue()

    fun clearPendingLoginUrl() = agyBackend.clearPendingLoginUrl()

    fun logoutFromAgyHub() {
        viewModelScope.launch {
            agyBackend.logoutFromAgyHub()
            refreshConnection()
        }
    }

    // ---- View mode -----------------------------------------------------------------------------

    private val _viewMode = MutableStateFlow(AppViewMode.CHAT)
    val viewMode: StateFlow<AppViewMode> = _viewMode.asStateFlow()

    /** Asks the shell to show a surface. Unknown names are ignored rather than crashed on. */
    fun requestViewMode(mode: String) {
        val parsed = runCatching { AppViewMode.valueOf(mode.uppercase()) }.getOrNull() ?: return
        _viewMode.value = parsed
    }

    fun requestViewMode(mode: AppViewMode) {
        _viewMode.value = mode
    }

    init {
        refreshConnection()
        agyBackend.refreshModelsAsync()
    }

    // ---- Actions --------------------------------------------------------------------------------

    fun refreshConnection() {
        viewModelScope.launch {
            _isNetworkConnectedState.value = isNetworkConnected()
            val info = agyBackend.agyHubClient.fetchAuthInfo().getOrDefault(
                AgyHubClient.AgyAuthInfo(status = AgyHubClient.AgyAuthStatus.OFFLINE, isOffline = true)
            )
            _agyAuthInfo.value = info
            _systemConnectionState.value = when {
                !_isNetworkConnectedState.value ->
                    SystemConnectionState.Error("There is no internet connection.")
                info.isOffline ->
                    SystemConnectionState.Unauthenticated("SAIF AI's local agent is not running yet.")
                !info.isLoggedIn ->
                    SystemConnectionState.Unauthenticated("Sign in to SAIF AI's agent to continue.")
                else -> SystemConnectionState.Ready("Connected", AuthPreferences.currentHubUrl)
            }
        }
    }

    fun loginToAgyHub(force: Boolean = false) {
        viewModelScope.launch {
            agyBackend.loginToAgyHub(force)
            refreshConnection()
        }
    }

    fun retryConnections() {
        viewModelScope.launch {
            agyBackend.retryConnections()
            agyBackend.refreshModelsAsync()
            refreshConnection()
        }
    }

    private fun isNetworkConnected(): Boolean {
        val manager = getApplication<Application>()
            .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}

/**
 * Holds the engine ViewModel outside any single screen.
 *
 * The agent has to survive the user navigating between chat, the IDE and the browser — cancelling a
 * run because a screen was closed would be worse than keeping a little memory alive. One store for
 * the whole process is the simplest thing that gives that guarantee.
 */
object SaifEngineViewModelHolder : ViewModelStoreOwner {

    private val globalStore = ViewModelStore()

    override val viewModelStore: ViewModelStore get() = globalStore

    @Volatile
    private var instance: SaifEngineViewModel? = null

    @Synchronized
    fun get(application: Application): SaifEngineViewModel {
        instance?.let { return it }
        val created = SaifEngineViewModel(application)
        instance = created
        return created
    }
}
