/*
 * Copyright (c) SAIF AI. All rights reserved.
 *
 * Build script for the SAIF AI application module.
 *
 * The version is read from version.json at the repository root so the number a person sees in
 * the app is the same number that is committed. On GitHub Actions the run number is folded into
 * the version code, which guarantees every CI build is a strictly newer package than the last:
 * without that, Android sometimes refuses to install a freshly built APK over an older one and
 * the phone keeps quietly running the previous version.
 */

import groovy.json.JsonSlurper

// ---------------------------------------------------------------------------------------------
// Version
// ---------------------------------------------------------------------------------------------

val versionFile = rootProject.file("version.json")
val parsedVersion: Map<String, Any> = if (versionFile.exists()) {
    @Suppress("UNCHECKED_CAST")
    JsonSlurper().parseText(versionFile.readText()) as Map<String, Any>
} else {
    mapOf("version_code" to 1, "version_name" to "1.0.0")
}

val baseVersionCode = (parsedVersion["version_code"] as? Number)?.toInt() ?: 1
val baseVersionName = (parsedVersion["version_name"] as? String) ?: "1.0.0"

val ciRunNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
val ciSha = (System.getenv("GITHUB_SHA") ?: "").take(7)

val appVersionCode = if (ciRunNumber != null) maxOf(baseVersionCode, 1000 + ciRunNumber) else baseVersionCode
val appVersionName = if (ciRunNumber != null) "$baseVersionName-b$ciRunNumber" else baseVersionName
val buildStamp = if (ciRunNumber != null) "build #$ciRunNumber ($ciSha)" else "local build"

/**
 * Reads an endpoint from the environment and refuses anything that is not a plain HTTPS URL.
 *
 * These end up baked into BuildConfig as Java string literals, so a stray quote or backslash
 * would not just be wrong, it would stop the file compiling. Validating here turns that into a
 * readable build error naming the offending variable.
 */
fun httpsEnv(key: String): String {
    val value = System.getenv(key).orEmpty().trim().trimEnd('/')
    require(value.isEmpty() || (value.startsWith("https://") && '"' !in value && '\\' !in value)) {
        "$key must be an HTTPS URL"
    }
    return value
}

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.google.devtools.ksp)
    alias(libs.plugins.google.services)
}

android {
    namespace = "com.example.saifai"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.saifai.app"
        // 26 is the floor for the bundled Linux workspace; 28 is the ceiling this build is
        // tested against, and raising it changes storage behaviour the app is not ready for.
        minSdk = 26
        targetSdk = 28
        versionCode = appVersionCode
        versionName = appVersionName
        buildConfigField("String", "BUILD_STAMP", "\"$buildStamp\"")

        // Optional model-provider keys. Read from the environment only; empty in a normal build,
        // in which case the user supplies their own key inside the app.
        buildConfigField("String", "GEMINI_API_KEY", "\"${System.getenv("GEMINI_API_KEY") ?: ""}\"")
        buildConfigField("String", "OPENROUTER_API_KEY", "\"${System.getenv("OPENROUTER_API_KEY") ?: ""}\"")

        // Public endpoint URLs. No secret ever goes in here.
        listOf("SAIF_CLOUD_API_BASE_URL", "SAIF_DOWNLOAD_PORTAL_URL", "SAIF_FIREBASE_DATABASE_URL")
            .forEach { key -> buildConfigField("String", key, "\"${httpsEnv(key)}\"") }

        // Telegram asset library, supplied as CI secrets; empty when not configured.
        buildConfigField("String", "TG_BOT_TOKEN", "\"${System.getenv("TG_BOT_TOKEN") ?: ""}\"")
        buildConfigField("String", "TG_CHAT_ID", "\"${System.getenv("TG_CHAT_ID") ?: ""}\"")

        // Source publication address. Point it at the exact commit being shipped so the binary
        // and its source can always be matched up afterwards.
        buildConfigField("String", "SAIF_SOURCE_URL", "\"${httpsEnv("SAIF_SOURCE_URL")}\"")
    }

    signingConfigs {
        // A fixed debug key lives in the repository on purpose. CI runners otherwise mint a new
        // random debug key per build, and Android then treats each APK as a different app:
        // installing over the previous one fails with "App not installed" and the phone silently
        // keeps running the old build.
        getByName("debug") {
            storeFile = file("saif-debug.jks")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    flavorDimensions += "mode"
    productFlavors {
        // The local bridge, hub and browser tool server each need their own port. They are fixed
        // here rather than searched for at runtime so the on-device firewall rules and the
        // workspace scripts can be written against known numbers.
        create("standard") {
            dimension = "mode"
            applicationId = "com.saifai.app"
            buildConfigField("int", "BRIDGE_PORT", "1236")
            buildConfigField("int", "HUB_PORT", "1237")
            buildConfigField("int", "BROWSER_MCP_PORT", "8767")
        }
    }

    buildTypes {
        debug {
            // Nothing to add: the default debug config already disables minification.
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    base {
        archivesName.set("app")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
        disable += "ExpiredTargetSdkVersion"
    }

    buildFeatures {
        compose = true
        buildConfig = true
        aidl = false
        shaders = false
    }

    androidResources {
        // Archives are streamed straight out of the assets folder by the workspace installer;
        // re-compressing them inside the APK would gain nothing and cost install size.
        noCompress += listOf("gz", "tgz", "tar.gz", "tar", "apk")
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/LICENSE*"
            excludes += "META-INF/NOTICE*"
            excludes += "META-INF/io.netty.versions.properties"
            excludes += "*.xsd"
            excludes += "**/*.xsd"
        }
    }
}

kotlin {
    jvmToolchain(21)
}

dependencies {
    val composeBom = platform(libs.androidx.compose.bom)
    implementation(composeBom)

    // --- Android foundation ---
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.webkit)
    implementation(libs.kotlinx.coroutines.android)
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // --- Compose UI ---
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    debugImplementation(libs.androidx.compose.ui.tooling)

    // --- Navigation 3 ---
    implementation(libs.androidx.navigation3.runtime)
    implementation(libs.androidx.navigation3.ui)
    implementation(libs.androidx.lifecycle.viewmodel.navigation3)

    // --- Networking and serialization ---
    implementation(libs.okhttp)
    implementation(libs.okhttp.sse)
    implementation(libs.kotlinx.serialization.json)

    // --- Markdown, LaTeX and images in assistant replies ---
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-svg:2.7.0")
    implementation("io.noties.markwon:ext-latex:4.6.2")
    implementation("ru.noties:jlatexmath-android:0.2.0")

    // --- Workspace: SSH into the local environment, and unpack its bootstrap archives ---
    implementation("com.github.mwiede:jsch:0.2.20")
    implementation("org.apache.commons:commons-compress:1.26.1")
    implementation("org.tukaani:xz:1.9")

    // --- Terminal emulator (native PTY); the terminal view itself is built from source ---
    implementation("com.github.termux.termux-app:terminal-emulator:v0.118.1")
    implementation("com.google.guava:listenablefuture:1.0")

    // --- Web tools used by the agent ---
    implementation("org.jsoup:jsoup:1.18.3")

    // --- Code editor ---
    implementation("io.github.Rosemoe.sora-editor:editor:0.23.6")
    implementation("io.github.Rosemoe.sora-editor:language-textmate:0.23.6")
    implementation("io.github.Rosemoe.sora-editor:language-java:0.23.6")

    // --- Offline speech recognition ---
    // Vosk (Apache 2.0) is what makes live conversation work with a provider that sells no
    // transcription endpoint: a user whose key is good for chat can still speak to SAIF AI.
    // The model is fetched on first use, so nothing large is baked into the APK.
    implementation("com.alphacephei:vosk-android:0.3.75@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")

    // --- Persistence ---
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // --- Sign-in and cloud sync ---
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.auth)
    implementation(libs.firebase.firestore)
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-appcheck-playintegrity")

    // --- Audio playback for speech output ---
    implementation(libs.media3.common)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)

    // --- On-device APK signing ---
    implementation(libs.apksig)
}

// OkHttp appears through several transitive paths; pinning one version keeps the SSL stack,
// the interceptor chain and the WebSocket code all agreeing on a single implementation.
configurations.all {
    resolutionStrategy {
        force("com.squareup.okhttp3:okhttp:4.12.0")
        force("com.squareup.okhttp3:okhttp-android:4.12.0")
    }
}

// The on-device compiler wraps a user's project inside a real Android app. That container is the
// :apprunner module's debug APK, copied into this module's assets under a fixed name so the
// compiler can find it at runtime without knowing anything about Gradle.
val bundleBaseRunnerApk by tasks.registering(Sync::class) {
    dependsOn(":apprunner:assembleDebug")
    from(project(":apprunner").layout.buildDirectory.dir("outputs/apk/debug")) {
        include("*.apk")
        exclude("*unaligned*")
        rename { "base_runner.apk" }
    }
    into(layout.buildDirectory.dir("generated/baseRunnerAssets"))
}

android.sourceSets.getByName("main").assets.srcDir(
    layout.buildDirectory.dir("generated/baseRunnerAssets").get().asFile
)

tasks.matching {
    (it.name.startsWith("merge") || it.name.startsWith("generate")) && it.name.endsWith("Assets")
}.configureEach { dependsOn(bundleBaseRunnerApk) }
tasks.named("preBuild").configure { dependsOn(bundleBaseRunnerApk) }

// ---------------------------------------------------------------------------------------------
// SAIF AI workspace daemon
// ---------------------------------------------------------------------------------------------
//
// The app needs a real process for the things a sandboxed Android app cannot do itself: walk a
// whole project tree, read and write arbitrary files, and hold sign-in state that outlives the UI.
// Historically that process came from a downloaded Linux root filesystem, which meant the app could
// not do anything at all until a large download succeeded - and when it never did, neither did
// the app.
//
// The daemon is a single Go file using nothing but the standard library, so it cross-compiles to a
// static binary with no dependencies. Shipping it inside the APK takes the download off the
// critical path entirely: the workspace exists the moment the app is installed.
//
// The binaries go into jniLibs because that is the one place Android guarantees files from the APK
// are unpacked onto the filesystem with the executable bit set. The "lib"/".so" naming is what the
// package manager looks for; nothing links against them, the app executes one directly.

val daemonSourceDir = rootProject.file("termux-daemon")
val daemonOutputDir = layout.buildDirectory.dir("generated/saifDaemon/jniLibs")

// Created now, not in the task: the task is skipped when there is no Go toolchain, and a source
// directory that does not exist is a problem for the merge step regardless of why it is empty.
daemonOutputDir.get().asFile.mkdirs()

/**
 * The ABIs a daemon is built for.
 *
 * arm64-v8a alone by default. Cross-compiling is not free: each ABI is a full compiler invocation
 * at a point in the build where Gradle and the Android plugin are already holding a lot of memory,
 * and on a hosted runner three of them is enough to tip it over. arm64 covers essentially every
 * Android device anyone is using. The other two are opt-in for whoever wants them and has the
 * headroom.
 */
val daemonAbis = mutableMapOf("arm64-v8a" to listOf("arm64", "")).apply {
    if (System.getenv("SAIF_DAEMON_ALL_ABIS").equals("true", ignoreCase = true)) {
        put("armeabi-v7a", listOf("arm", "7"))
        put("x86_64", listOf("amd64", ""))
    }
}

/** True when a Go toolchain is on the PATH. */
fun hasGoToolchain(): Boolean = try {
    val probe = ProcessBuilder("go", "version").redirectErrorStream(true).start()
    probe.inputStream.bufferedReader().readText()
    probe.waitFor() == 0
} catch (_: Exception) {
    false
}

/**
 * Cross-compiles the daemon for one ABI and reports whether a usable binary came out, together
 * with whatever the compiler said.
 *
 * ProcessBuilder rather than the Gradle exec API: a task's action has no exec of its own, and
 * reaching for the project's from inside one is the sort of thing that reads fine and then does
 * not resolve. This needs no Gradle plumbing at all - it is one command with a few environment
 * variables - so it does not pay for any.
 */
fun buildDaemonFor(goArch: String, goArm: String, outFile: java.io.File): Pair<Boolean, String> =
    runCatching {
        val command = listOf(
            "go", "build",
            "-trimpath",
            "-buildmode=pie",
            "-ldflags=-s -w",
            "-o", outFile.absolutePath,
            "server.go"
        )
        val process = ProcessBuilder(command).apply {
            directory(daemonSourceDir)
            // Merged, so a compiler that writes a lot cannot fill the pipe and stall.
            redirectErrorStream(true)
            // Pure Go, no cgo: the Android NDK is not needed and no C toolchain has to be
            // discovered. The result is a static PIE binary, which is what lets Android execute
            // it straight out of the app's native library directory.
            environment()["CGO_ENABLED"] = "0"
            environment()["GOOS"] = "android"
            environment()["GOARCH"] = goArch
            if (goArm.isNotEmpty()) environment()["GOARM"] = goArm
        }.start()

        val output = StringBuilder()
        val drainer = Thread {
            runCatching {
                process.inputStream.bufferedReader().forEachLine { line ->
                    if (output.length < 4000) output.appendLine(line)
                }
            }
        }.apply { isDaemon = true; start() }

        // Polled rather than waiting on a TimeUnit: inside a Gradle script `java` is the java
        // extension, so the fully-qualified name does not resolve the way it would in plain Kotlin.
        val deadline = System.currentTimeMillis() + 600_000
        while (process.isAlive && System.currentTimeMillis() < deadline) {
            Thread.sleep(200)
        }
        val finished = !process.isAlive
        drainer.join(2_000)
        if (!finished) {
            process.destroy()
            return@runCatching Pair(false, "timed out after 10 minutes")
        }
        Pair(
            process.exitValue() == 0 && outFile.exists() && outFile.length() > 0,
            output.toString()
        )
    }.getOrDefault(Pair(false, "the Go compiler could not be started"))

val buildSaifDaemon by tasks.registering {
    inputs.dir(daemonSourceDir)
    daemonAbis.keys.forEach { abi ->
        outputs.file(daemonOutputDir.get().dir(abi).file("libsaifdaemon.so"))
    }

    // No Go toolchain means no bundled daemon. That degrades the workspace rather than breaking
    // the app, so the build continues and the app reports the workspace as unavailable instead of
    // waiting forever on something that cannot start.
    onlyIf { hasGoToolchain() }

    doLast {
        var built = 0
        daemonAbis.forEach { (abi, archAndArm) ->
            val (goArch, goArm) = archAndArm
            val outFile = daemonOutputDir.get().dir(abi).file("libsaifdaemon.so").asFile
            outFile.parentFile.mkdirs()
            if (outFile.exists()) outFile.delete()

            val (ok, output) = buildDaemonFor(goArch, goArm, outFile)
            if (ok) {
                built++
                logger.lifecycle("SAIF AI workspace daemon built for $abi (${outFile.length()} bytes)")
            } else {
                // One ABI failing must not sink the others, nor the release.
                logger.warn("SAIF AI workspace daemon could not be built for $abi: ${output.take(400)}")
                outFile.delete()
            }
        }
        // Recorded outside jniLibs so only real .so files ever land in the APK.
        layout.buildDirectory.dir("generated/saifDaemon").get().file("built.txt").asFile
            .apply { parentFile.mkdirs() }.writeText(built.toString())
        if (built == 0) {
            logger.warn("No SAIF AI workspace daemon was built; the bundled workspace will be unavailable.")
        }
    }
}

android.sourceSets.getByName("main").jniLibs.srcDir(
    daemonOutputDir.get().asFile
)

tasks.matching { it.name.startsWith("merge") && it.name.endsWith("JniLibFolders") }
    .configureEach { dependsOn(buildSaifDaemon) }
tasks.named("preBuild").configure { dependsOn(buildSaifDaemon) }
