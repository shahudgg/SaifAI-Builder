# SAIF AI

SAIF AI is an on-device AI assistant and development environment for Android.

It combines a chat assistant, a tool-using agent, a Linux workspace, a terminal and an
APK builder in a single app. Everything runs on the phone: the conversation, the agent's
tools, and the workspace it edits.

## What is inside

| Area | Package | What it does |
|---|---|---|
| Assistant chat | `com.example.ui` | The chat surface, settings and onboarding |
| Model gateway | `com.example.llm` | Provider routing, retries, rate limits, model catalogues |
| Agent runtime | `com.example.saifagent` | The tool-calling loop: files, search, shell, web |
| Agent engine | `com.example.saifcore` | Conversations, tool approvals, the engine ViewModel |
| Linux workspace | `com.example.saifcore` | Installing and verifying a local userland |
| Terminal | `com.example.terminal` | Terminal providers and provisioning |
| Builder | `com.example.builder`, `com.example.compiler` | Building and installing APKs on the device |
| Studio, cloud, live voice | `com.example.studio`, `com.example.cloud`, `com.example.live` | Media, remote jobs, hands-free voice |

## The agent

The agent works in one workspace directory inside the app's private storage. It can read,
write, search and run commands there. It asks before anything that changes the device, and
a refusal is fed back to the model as information rather than ending the run.

## Building

```
./gradlew :app:assembleStandardDebug
```

Requires JDK 17 and the Android SDK. A GitHub Actions workflow builds a debug APK from the
archived source on every push.

## Licence

SAIF AI's own code is copyright SAIF AI. See `LICENSE` and `THIRD_PARTY_NOTICES.md` for the
licences of everything this app ships, including third-party open-source components.
