# Working on this repository

This document is for people and tools making changes to SAIF AI.

## Layout

The app is one Gradle module, `:app`, plus `:automation` and `:apprunner`. Kotlin sources live
under `app/src/main/java/com/example/`.

## Ownership

Files under `com.example.ui`, `com.example.llm`, `com.example.agent`, `com.example.saifagent`,
`com.example.saifcore`, `com.example.builder`, `com.example.compiler`, `com.example.studio`,
`com.example.terminal`, `com.example.cloud`, `com.example.data`, `com.example.github`,
`com.example.audio`, `com.example.stt`, `com.example.live` and `com.example.utils` are SAIF AI's
own work. Each carries the SAIF AI copyright header.

## Rules for changes

1. Every new Kotlin file starts with the SAIF AI header. Run
   `python3 tools/licence/add_saif_headers.py` to stamp anything that is missing it.
2. Do not copy code from other projects. If a subsystem has to be replaced, write it fresh.
3. `python3 tools/licence/provenance.py --upstream <upstream-checkout> --write` reports how much
   of the tree derives from elsewhere. Keep that number at zero.
4. The agent must stay inside its workspace, and anything that writes or runs must ask first.

## Verification

There is no local toolchain in every environment; the GitHub Actions workflow
`build-saif-ai-apk.yml` builds the APK and fails on compiler errors. Make your changes in a
batch, then run the workflow once.
